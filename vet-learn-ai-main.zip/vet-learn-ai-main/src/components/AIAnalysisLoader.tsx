import { useState, useEffect } from 'react';
import { Brain, Check } from 'lucide-react';

interface AIAnalysisLoaderProps {
  caseType?: string;
}

const AIAnalysisLoader = ({ caseType = 'case' }: AIAnalysisLoaderProps) => {
  const [currentStep, setCurrentStep] = useState(0);
  
  const analysisSteps = [
    "Analyzing radiographic images...",
    "Evaluating systematic approach...",
    "Comparing with VET.CT Radiologists' findings...", 
    "Assessing technical quality...",
    "Generating personalized feedback...",
    "Creating learning recommendations...",
    "Finalizing your report..."
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentStep((prev) => {
        if (prev < analysisSteps.length - 1) {
          return prev + 1;
        }
        return prev; // Stop at the last step, don't cycle
      });
    }, 2000);

    return () => clearInterval(interval);
  }, [analysisSteps.length]);

  return (
    <div className="flex flex-col items-center justify-center py-16 space-y-8">
      {/* Animated Brain */}
      <div className="relative">
        <div className="absolute inset-0 bg-primary/20 rounded-full animate-ping"></div>
        <div className="relative bg-gradient-to-br from-primary to-primary/80 p-6 rounded-full animate-pulse">
          <Brain className="w-12 h-12 text-white animate-bounce" />
        </div>
        
        {/* Pulse rings */}
        <div className="absolute inset-0 bg-primary/10 rounded-full animate-ping animation-delay-1000"></div>
        <div className="absolute inset-0 bg-primary/5 rounded-full animate-ping animation-delay-2000"></div>
      </div>

      {/* Title */}
      <div className="text-center space-y-2">
        <h2 className="text-2xl font-bold text-primary">
          Dr Watson is analyzing your submission
        </h2>
        <p className="text-muted-foreground">
          Please wait while we generate personalized feedback...
        </p>
      </div>

      {/* Dynamic Checklist */}
      <div className="bg-white/60 backdrop-blur-sm border border-border/50 rounded-xl p-6 w-full max-w-md shadow-lg">
        <h3 className="font-semibold text-primary mb-4 text-center">Analysis Progress</h3>
        <div className="space-y-3">
          {analysisSteps.map((step, index) => (
            <div key={index} className="flex items-center space-x-3">
              <div className={`w-5 h-5 rounded-full flex items-center justify-center transition-all duration-500 ${
                index < currentStep 
                  ? 'bg-green-500 scale-110' 
                  : index === currentStep 
                    ? 'bg-primary animate-pulse scale-110' 
                    : 'bg-muted border border-border'
              }`}>
                {index < currentStep ? (
                  <Check className="w-3 h-3 text-white animate-scale-in" />
                ) : index === currentStep ? (
                  <div className="w-2 h-2 bg-white rounded-full animate-pulse" />
                ) : null}
              </div>
              <span className={`text-sm transition-all duration-300 ${
                index === currentStep 
                  ? 'text-primary font-medium animate-fade-in' 
                  : index < currentStep 
                    ? 'text-green-600 font-medium' 
                    : 'text-muted-foreground'
              }`}>
                {step}
              </span>
            </div>
          ))}
        </div>
        
        {/* Processing Status */}
        <div className="mt-6 text-center">
          {currentStep === analysisSteps.length - 1 ? (
            <div className="flex items-center justify-center space-x-2">
              <div className="w-2 h-2 bg-primary rounded-full animate-pulse"></div>
              <span className="text-sm text-primary font-medium animate-pulse">
                Finalizing analysis...
              </span>
              <div className="w-2 h-2 bg-primary rounded-full animate-pulse animation-delay-1000"></div>
            </div>
          ) : (
            <div className="text-xs text-muted-foreground">
              Step {currentStep + 1} of {analysisSteps.length}
            </div>
          )}
        </div>
      </div>

      {/* Fun fact or tip */}
      <div className="text-center text-sm text-muted-foreground max-w-md">
        <p className="italic">
          💡 Did you know? Our AI analyzes over 50 different radiographic features to provide you with comprehensive feedback tailored to your learning level.
        </p>
      </div>
    </div>
  );
};

export default AIAnalysisLoader;