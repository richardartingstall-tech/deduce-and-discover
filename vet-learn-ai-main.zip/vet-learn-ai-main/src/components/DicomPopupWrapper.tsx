import { Button } from "@/components/ui/button";
import { ExternalLink, X } from "lucide-react";
import { useEffect, useState } from "react";

interface DicomPopupWrapperProps {
  dicomUrl: string;
}

export const DicomPopupWrapper = ({ dicomUrl }: DicomPopupWrapperProps) => {
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Focus the window when it loads
    window.focus();
  }, []);

  const handleOpenInNewTab = () => {
    window.open(dicomUrl, '_blank', 'noopener,noreferrer');
  };

  const handleClosePopup = () => {
    window.close();
  };

  const handleIframeLoad = () => {
    setIsLoading(false);
  };

  return (
    <div className="h-screen w-full bg-white flex flex-col">
      {/* Header with controls */}
      <div className="flex items-center justify-between p-4 border-b bg-gray-50">
        <div className="flex items-center gap-2">
          <h1 className="text-lg font-semibold text-primary">Radiographic Images</h1>
          {isLoading && (
            <span className="text-sm text-gray-500">Loading...</span>
          )}
        </div>
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={handleOpenInNewTab}
            className="flex items-center gap-2"
          >
            <ExternalLink size={16} />
            Open in New Tab
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={handleClosePopup}
            className="flex items-center gap-2"
          >
            <X size={16} />
            Close
          </Button>
        </div>
      </div>

      {/* DICOM Viewer iframe */}
      <div className="flex-1 relative">
        {isLoading && (
          <div className="absolute inset-0 flex items-center justify-center bg-gray-100">
            <div className="text-center">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
              <p className="text-gray-600">Loading DICOM viewer...</p>
            </div>
          </div>
        )}
        <iframe
          src={dicomUrl}
          className="w-full h-full border-0"
          title="DICOM Viewer"
          onLoad={handleIframeLoad}
          style={{ minHeight: '500px' }}
        />
      </div>
    </div>
  );
};