import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { ExternalLink, AlertCircle } from "lucide-react";
import { useState } from "react";

interface DicomViewerModalProps {
  isOpen: boolean;
  onClose: () => void;
  viewerUrl: string;
  caseTitle: string;
}

export const DicomViewerModal = ({ isOpen, onClose, viewerUrl, caseTitle }: DicomViewerModalProps) => {
  const [isLoading, setIsLoading] = useState(true);
  const [hasError, setHasError] = useState(false);

  const handleIframeLoad = () => {
    setIsLoading(false);
    setHasError(false);
  };

  const handleIframeError = () => {
    setIsLoading(false);
    setHasError(true);
  };

  const handleOpenInNewTab = () => {
    window.open(viewerUrl, '_blank', 'noopener,noreferrer');
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-6xl h-[80vh] p-0">
        <DialogHeader className="p-6 pb-0">
          <DialogTitle className="flex items-center justify-between">
            Radiographic Images
            <Button
              variant="outline"
              size="sm"
              onClick={handleOpenInNewTab}
              className="flex items-center gap-2"
            >
              <ExternalLink className="h-4 w-4" />
              Open in New Tab
            </Button>
          </DialogTitle>
        </DialogHeader>

        <div className="flex-1 relative p-6 pt-2">
          {isLoading && !hasError && (
            <div className="absolute inset-6 flex items-center justify-center bg-gray-50 rounded-lg">
              <div className="text-center">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
                <p className="text-gray-600">Loading DICOM viewer...</p>
              </div>
            </div>
          )}

          {hasError && (
            <div className="absolute inset-6 flex items-center justify-center bg-gray-50 rounded-lg">
              <div className="text-center">
                <AlertCircle className="h-12 w-12 text-red-500 mx-auto mb-4" />
                <p className="text-gray-600 mb-4">Unable to load DICOM viewer in this window</p>
                <Button onClick={handleOpenInNewTab} className="flex items-center gap-2">
                  <ExternalLink className="h-4 w-4" />
                  Open in New Tab Instead
                </Button>
              </div>
            </div>
          )}

          <iframe
            src={viewerUrl}
            className="w-full h-full border-0 rounded-lg"
            title="DICOM Viewer"
            onLoad={handleIframeLoad}
            onError={handleIframeError}
            style={{ minHeight: '500px', display: hasError ? 'none' : 'block' }}
          />
        </div>
      </DialogContent>
    </Dialog>
  );
};