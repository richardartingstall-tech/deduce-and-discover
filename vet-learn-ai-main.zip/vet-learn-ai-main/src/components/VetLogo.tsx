import { cn } from "@/lib/utils";
import vetCtLogo from "@/assets/vet-ct-logo.png";

interface VetLogoProps {
  className?: string;
  size?: "sm" | "md" | "lg";
}

export const VetLogo = ({ className, size = "md" }: VetLogoProps) => {
  const sizeClasses = {
    sm: "w-fit max-w-2xl h-12",
    md: "w-fit max-w-4xl h-20", 
    lg: "w-fit max-w-5xl h-20"
  };

  return (
    <div className={cn(
      "flex items-center justify-center bg-white rounded-lg border-4 border-primary shadow-medical",
      sizeClasses[size],
      className
    )}>
      <div className="flex items-center justify-center gap-3 px-6">
        <img 
          src={vetCtLogo} 
          alt="VET.CT Logo" 
          className="h-12 w-auto object-contain"
        />
        <span className="text-primary font-bold tracking-wider text-xl whitespace-nowrap">
          Dr Watson - the VET.CT Teaching Tool
        </span>
      </div>
    </div>
  );
};