import { cn } from "@/lib/utils";

interface PageHeaderProps {
  children: React.ReactNode;
  className?: string;
}

export const PageHeader = ({ children, className }: PageHeaderProps) => {
  return (
    <div className={cn(
      "w-full max-w-4xl mx-auto px-6 py-4 text-center bg-white rounded-2xl border-2 border-gray-200 shadow-sm mb-8 text-2xl",
      className
    )}>
      <h1 className="font-semibold text-gray-800 tracking-wide">
        {children}
      </h1>
    </div>
  );
};