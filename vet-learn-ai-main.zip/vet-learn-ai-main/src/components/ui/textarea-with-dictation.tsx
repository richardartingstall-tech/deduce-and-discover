import * as React from "react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Mic, MicOff, Square } from "lucide-react";
import { useSpeechRecognition } from "@/hooks/useSpeechRecognition";
import { useEffect, useRef } from "react";

export interface TextareaWithDictationProps
  extends React.TextareaHTMLAttributes<HTMLTextAreaElement> {
  onValueChange?: (value: string) => void;
}

const TextareaWithDictation = React.forwardRef<HTMLTextAreaElement, TextareaWithDictationProps>(
  ({ className, onValueChange, onChange, value = "", ...props }, ref) => {
    const {
      isListening,
      transcript,
      startListening,
      stopListening,
      resetTranscript,
      isSupported,
      error
    } = useSpeechRecognition();

    const textareaRef = useRef<HTMLTextAreaElement>(null);
    const cursorPositionRef = useRef<number>(0);
    const processedTranscriptLengthRef = useRef<number>(0);

    // Update cursor position when user clicks or changes selection
    const handleSelectionChange = () => {
      if (textareaRef.current) {
        cursorPositionRef.current = textareaRef.current.selectionStart;
      }
    };

    useEffect(() => {
      if (transcript && isListening && transcript.length > processedTranscriptLengthRef.current) {
        const currentValue = typeof value === 'string' ? value : '';
        const newTranscriptPortion = transcript.slice(processedTranscriptLengthRef.current);
        
        const beforeCursor = currentValue.slice(0, cursorPositionRef.current);
        const afterCursor = currentValue.slice(cursorPositionRef.current);
        
        // Determine if this new portion is a continuation of the current word
        const prevCharInTranscript = transcript.charAt(processedTranscriptLengthRef.current - 1);
        const isContinuationOfWord = processedTranscriptLengthRef.current > 0 && prevCharInTranscript !== '' && !/[\s.,!?;:]/.test(prevCharInTranscript);
        const spacing = !isContinuationOfWord && beforeCursor.length > 0 && !beforeCursor.endsWith(' ') && !newTranscriptPortion.startsWith(' ')
          ? ' '
          : '';
        const newValue = beforeCursor + spacing + newTranscriptPortion + afterCursor;
        
        // Update cursor position to account for the inserted text
        const insertedTextLength = spacing.length + newTranscriptPortion.length;
        cursorPositionRef.current += insertedTextLength;
        
        if (onValueChange) {
          onValueChange(newValue);
        }
        
        // Create synthetic change event for backward compatibility
        if (onChange && textareaRef.current) {
          const syntheticEvent = {
            target: { value: newValue },
            currentTarget: { value: newValue }
          } as React.ChangeEvent<HTMLTextAreaElement>;
          onChange(syntheticEvent);
        }
        
        processedTranscriptLengthRef.current = transcript.length;
      }
    }, [transcript, onValueChange, onChange, isListening]);

    const handleStartDictation = () => {
      if (textareaRef.current) {
        cursorPositionRef.current = textareaRef.current.selectionStart;
      }
      resetTranscript();
      processedTranscriptLengthRef.current = 0;
      startListening();
    };

    const handleStopDictation = () => {
      stopListening();
      resetTranscript();
      processedTranscriptLengthRef.current = 0;
    };

    const handleTextareaChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
      if (onChange) {
        onChange(e);
      }
      if (onValueChange) {
        onValueChange(e.target.value);
      }
    };

    return (
      <div className="relative">
        <textarea
          ref={ref || textareaRef}
          className={cn(
            "flex min-h-[80px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-xs placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 pr-12",
            className
          )}
          value={value}
          onChange={handleTextareaChange}
          onSelect={handleSelectionChange}
          onKeyUp={handleSelectionChange}
          onMouseUp={handleSelectionChange}
          {...props}
        />
        
        {/* Dictation Controls */}
        <div className="absolute bottom-2 right-2 flex items-center gap-1">
          {isSupported && (
            <>
              {!isListening ? (
                <Button
                  type="button"
                  size="sm"
                  variant="ghost"
                  className="h-9 w-9 p-0 hover:bg-primary/20 bg-primary/10 border border-primary/30 shadow-sm hover:shadow-md transition-all duration-200"
                  onClick={handleStartDictation}
                  title="Start dictation"
                >
                  <Mic className="h-5 w-5 text-primary" />
                </Button>
              ) : (
                <Button
                  type="button"
                  size="sm"
                  variant="ghost"
                  className="h-9 w-9 p-0 hover:bg-destructive/20 bg-destructive/10 border border-destructive/30 shadow-sm hover:shadow-md animate-pulse transition-all duration-200"
                  onClick={handleStopDictation}
                  title="Stop dictation"
                >
                  <Square className="h-5 w-5 text-destructive fill-destructive" />
                </Button>
              )}
            </>
          )}
          
          {!isSupported && (
            <div title="Dictation not supported">
              <MicOff className="h-4 w-4 text-muted-foreground" />
            </div>
          )}
        </div>
        
        {/* Error display */}
        {error && (
          <div className="absolute top-full left-0 mt-1 text-xs text-destructive">
            {error}
          </div>
        )}
        
        {/* Recording indicator */}
        {isListening && (
          <div className="absolute top-2 right-12 flex items-center gap-1 text-xs text-destructive">
            <div className="h-2 w-2 bg-destructive rounded-full animate-pulse" />
            Recording...
          </div>
        )}
      </div>
    );
  }
);
TextareaWithDictation.displayName = "TextareaWithDictation";

export { TextareaWithDictation };