import { useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { useSessionLimits } from './useSessionLimits';

export interface CaseSubmissionData {
  caseType: 'thoracic' | 'abdominal' | 'musculoskeletal';
  caseTitle: string;
  signalment: string;
  history: string;
  imageLinks: string[];
  studyDescription: string;
  findings: string;
  conclusions: string;
  discussion: string;
}

export interface FeedbackData {
  caseSubmissionId: string;
  aiFeedback: any;
  personalReview?: string;
  learningRating?: number;
  difficultyRating?: number;
}

export const useCaseSubmissions = () => {
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();
  const { isLimitReached, incrementSubmissionCount, submissionCount, submissionLimit, getRemainingSubmissions } = useSessionLimits();

  const saveCaseSubmission = async (submissionData: CaseSubmissionData) => {
    // Check session limit before proceeding
    if (isLimitReached) {
      toast({
        title: "Submission Limit Reached",
        description: `You have reached the maximum of ${submissionLimit} submissions per session. Please refresh your browser to start a new session.`,
        variant: "destructive",
      });
      return null;
    }

    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('case_submissions')
        .insert({
          case_type: submissionData.caseType,
          case_title: submissionData.caseTitle,
          signalment: submissionData.signalment,
          history: submissionData.history,
          image_links: submissionData.imageLinks,
          study_description: submissionData.studyDescription,
          findings: submissionData.findings,
          conclusions: submissionData.conclusions,
          discussion: submissionData.discussion,
          user_id: null, // Allow anonymous submissions
        })
        .select()
        .single();

      if (error) throw error;

      // Increment submission count after successful save
      incrementSubmissionCount();

      toast({
        title: "Submission Saved",
        description: "Your case submission has been saved successfully.",
      });

      return data;
    } catch (error) {
      console.error('Error saving case submission:', error);
      toast({
        title: "Error",
        description: "Failed to save case submission. Please try again.",
        variant: "destructive",
      });
      return null;
    } finally {
      setLoading(false);
    }
  };

  const saveFeedback = async (feedbackData: FeedbackData) => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('case_feedback')
        .insert({
          case_submission_id: feedbackData.caseSubmissionId,
          ai_feedback: feedbackData.aiFeedback,
          personal_review: feedbackData.personalReview,
          learning_rating: feedbackData.learningRating,
          difficulty_rating: feedbackData.difficultyRating,
        })
        .select()
        .single();

      if (error) throw error;

      toast({
        title: "Feedback Saved",
        description: "Your feedback has been saved successfully.",
      });

      return data;
    } catch (error: any) {
      console.error('Error saving feedback:', error);
      
      // Provide more specific error messages based on the error type
      let errorMessage = "Failed to save feedback. Please try again.";
      if (error?.code === 'PGRST116') {
        errorMessage = "Unable to save feedback - permission denied.";
      } else if (error?.message?.includes('violates row-level security')) {
        errorMessage = "Permission denied - unable to save feedback for this submission.";
      }
      
      toast({
        title: "Error",
        description: errorMessage,
        variant: "destructive",
      });
      return null;
    } finally {
      setLoading(false);
    }
  };

  const getCaseSubmissions = async () => {
    try {
      const { data, error } = await supabase
        .from('case_submissions')
        .select(`
          *,
          case_feedback (*)
        `)
        .order('created_at', { ascending: false });

      if (error) throw error;
      return data;
    } catch (error) {
      console.error('Error fetching case submissions:', error);
      return [];
    }
  };

  const getCaseTemplate = async (caseType: string) => {
    try {
      const { data, error } = await supabase
        .from('case_templates')
        .select('learning_objectives, next_steps')
        .eq('case_type', caseType)
        .maybeSingle();

      if (error) throw error;
      return data;
    } catch (error) {
      console.error('Error fetching case template:', error);
      return null;
    }
  };

  return {
    loading,
    saveCaseSubmission,
    saveFeedback,
    getCaseSubmissions,
    getCaseTemplate,
    submissionCount,
    submissionLimit,
    isLimitReached,
    getRemainingSubmissions,
  };
};