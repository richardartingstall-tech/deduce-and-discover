import { useState, useEffect } from 'react';

const SUBMISSION_LIMIT = 3;
const SESSION_KEY = 'case_submissions_count';

export const useSessionLimits = () => {
  const [submissionCount, setSubmissionCount] = useState(0);
  const [isLimitReached, setIsLimitReached] = useState(false);

  useEffect(() => {
    // Load current count from session storage
    const storedCount = sessionStorage.getItem(SESSION_KEY);
    const count = storedCount ? parseInt(storedCount, 10) : 0;
    setSubmissionCount(count);
    setIsLimitReached(count >= SUBMISSION_LIMIT);
  }, []);

  const incrementSubmissionCount = () => {
    const newCount = submissionCount + 1;
    setSubmissionCount(newCount);
    setIsLimitReached(newCount >= SUBMISSION_LIMIT);
    sessionStorage.setItem(SESSION_KEY, newCount.toString());
  };

  const resetSessionLimit = () => {
    setSubmissionCount(0);
    setIsLimitReached(false);
    sessionStorage.removeItem(SESSION_KEY);
  };

  const getRemainingSubmissions = () => {
    return Math.max(0, SUBMISSION_LIMIT - submissionCount);
  };

  return {
    submissionCount,
    isLimitReached,
    submissionLimit: SUBMISSION_LIMIT,
    incrementSubmissionCount,
    resetSessionLimit,
    getRemainingSubmissions,
  };
};