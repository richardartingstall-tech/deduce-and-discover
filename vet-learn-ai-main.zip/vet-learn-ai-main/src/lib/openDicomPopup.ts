export function openDicomPopup(url: string) {
  // Open the provided DICOM viewer URL directly in a new tab
  const win = window.open(url, '_blank', 'noopener');
  try {
    win?.focus();
  } catch {}
  return win ?? null;
}

