import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { TextareaWithDictation } from "@/components/ui/textarea-with-dictation";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { CheckCircle, AlertCircle, Info, Trophy, Download, ArrowLeft, FileText, Star, AlertTriangle, ChevronRight, Zap, ChevronDown } from "lucide-react";
import { useNavigate, useLocation } from "react-router-dom";
import { useState, useEffect, useRef } from "react";
import { useCaseSubmissions, CaseSubmissionData } from '@/hooks/useCaseSubmissions';
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import AIAnalysisLoader from '@/components/AIAnalysisLoader';
import { VetLogo } from "@/components/VetLogo";

// Default submissions for different case types
const defaultSubmissions = {
  thoracic: {
    studyDescription: "Five radiographs of the thorax are presented for evaluation. There are 2 VD views, 2 left laterals and a right lateral.\n\nRadiographs are of adequate diagnostic quality. Images are appropriately labelled as well as displayed. Patient positioning is appropriate for all views.",
    findings: "Cardiac silhouette is smooth and of adequate opacity, size, and shape although there is some overlap with increased soft tissue or fluid radiopacity at the cranial aspect.\n\nThese soft tissue opacities appear to be lobular, multiple in varying sizes, and lay in the right cranial thorax and into the subcutaneous tissue of the right axilla.\n\nBronchiole and interstitial patterns are noted diffusely bilaterally throughout the lung lobes. Pulmonary vasculature is not noted to be tortuous or enlarged.\n\nRegarding what is able to be seen of the abdomen: no abnormalities are noted from these images.",
    conclusions: "a. Lobular soft tissue masses in right cranial thorax\n\nb. Bronchiole and interstitial pattern to the lung lobes",
    discussion: "a. Based off of patient history and signalment the lobular soft tissue masses are highly suspicious of neoplasia (extra versus intra thoracic) and may be contributing to the stilted gait as well as progressive cough noted by the owner.\n\nb. Bronchiole and interstitial pattern to the lungs can indicate a mild pneumonia.\n\nc. Differentials: Lipoma, fibrosarcoma, chondrosarcoma, lymphoma\n\nFine needle aspirate of the lobular masses would be the first step in determining the cause. After aspirate of the mass we could aspirate the peripheral lymph nodes.\n\nIf we still do not have a definitive answer the next step would be a surgical biopsy of the mass. As the radiographs are indeterminate regarding the infiltration of the mass between extra vs intrathoracic I would like a CT to be performed to determine the scope of the masses."
  },
  abdominal: {
    studyDescription: "Four radiographs of the abdomen are presented for evaluation. There are 2 VD views and 2 right laterals. A left lateral was not presented for evaluation but is recommended for complete evaluation of the abdomen.\n\nRadiographs are of good diagnostic quality and are appropriately labelled as well as displayed. Patient positioning is appropriate for each of the views.",
    findings: "The liver has a homogenous radiopacity and is of adequate size, shape, and contour although there is border effacement noted at the caudal edge. The gastric axis is almost perpendicular to the vertebra and appears to be shifted cranially.\n\nThe kidneys on lateral have smooth borders with adequate radiopacity and are summated on one another. The spleen is indistinguishable in these images. The descending colon contains a gas opacity and is dorsally deviated.\n\nThe bladder is distended but does not contain any mineralized opacities within its lumen. Uterine lumen is distended and has a homogenous fluid or soft tissue opacity. It is noted to extend cranially which has led to the other abdominal structures being displaced craniodorsally.\n\nNo mineral opacities are noted within the lumen of the uterus. Dense mammary tissue is noted with increased radiopacity most notably on the VD view. All other extra-abdominal structures noted in the images are unremarkable",
    conclusions: "a. Uteromegaly\n\nb. Displaced abdominal organs",
    discussion: "The main anatomical feature of concern in these images is the dilated uterus with a homogenous fluid or soft tissue opacity which is displacing the other abdominal organs craniodorsally. Based off of the patient history and signalment pyometra should be highly considered. Other disease processes of the uterus including pregnancy cannot be ruled out based off of radiographs alone.\n\nDifferentials: Pyometra, hydrometra, mucometra, pregnancy (if <45 days due to lack of bone mineralization), cystic endometrial hyperplasia, neoplasia (leiomyoma or leiomyosarcomas), uterine torsion\n\nThe patient's systemic health should be evaluated with baseline bloodwork including a CBC and chemistry panel. Abdominal ultrasound can be performed to evaluate the contents of the uterus as well as evaluate the other abdominal organs.\n\nFurther patient stabilization methods can be instituted depending on systemic health of the patient, and then surgery is recommended. Ovariohysterectomy is the main surgical procedure recommended, but an exploratory laparotomy can also be performed"
  },
  musculoskeletal: {
    studyDescription: "Three radiographs of the right stifle are presented for evaluation. There is a lateral view, a craniocaudal view, and an oblique view.\n\nRadiographs are of good diagnostic quality and are appropriately labelled as well as displayed. Patient positioning is appropriate for each of the views.",
    findings: "There is a complete transverse fracture through the mid-diaphysis of the femur with mild displacement. The fracture margins are sharp and well-defined. There is minimal soft tissue swelling surrounding the fracture site.\n\nThe patella appears normally positioned. The joint spaces of the stifle appear within normal limits. The tibia and fibula show no evidence of fracture or abnormality.\n\nNo evidence of degenerative joint disease is noted in the stifle joint. The surrounding soft tissues show minimal swelling consistent with acute trauma.",
    conclusions: "a. Complete transverse mid-diaphyseal femoral fracture with mild displacement\n\nb. Minimal soft tissue swelling",
    discussion: "The complete transverse fracture of the femoral diaphysis is consistent with acute trauma as reported in the history. The minimal displacement suggests the fracture is relatively stable.\n\nDifferentials for treatment include surgical repair with internal fixation versus external fixation depending on the patient's size, age, and activity level.\n\nRecommendations include immediate stabilization of the fracture, pain management, and surgical consultation for fracture repair. Pre-operative bloodwork and chest radiographs should be considered prior to anesthesia.\n\nPost-operative monitoring will include follow-up radiographs to assess healing and implant position."
  }
};

// Static fallback data
const thoracicFeedback = [
  {
    title: "Technique",
    content: "You correctly identified adequate thoracic radiographs and commented on their quality.",
    type: "excellent"
  },
  {
    title: "Description", 
    content: "You identified lobular soft tissue masses but could enhance detail on bone changes.",
    type: "improvement"
  }
];

const thoracicComparison = {
  categories: [
    {
      category: "Mass description",
      yourReport: "Lobular soft tissue masses in right cranial thorax",
      vetCtReport: "Large lobulated soft tissue mass centred on right 4th rib"
    }
  ]
};

const thoracicRecommendations = [
  "Focus on systematic application of roentgen signs",
  "Consider bone involvement when masses are near ribs"
];

// Fallback functions
const getFallbackFeedback = () => thoracicFeedback;
const getFallbackComparison = () => thoracicComparison;
const getFallbackRecommendations = () => thoracicRecommendations;

const AIFeedback = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { toast } = useToast();
  const { saveFeedback, saveCaseSubmission } = useCaseSubmissions();
  const [personalReview, setPersonalReview] = useState("");
  const [learningRating, setLearningRating] = useState(0);
  const [difficultyRating, setDifficultyRating] = useState(0);
  const [aiFeedback, setAiFeedback] = useState<any[]>([]);
  const [aiComparison, setAiComparison] = useState<any>({ categories: [] });
  const [aiRecommendations, setAiRecommendations] = useState<string[]>([]);
  const [isLoadingFeedback, setIsLoadingFeedback] = useState(true);
  const [isSubmissionExpanded, setIsSubmissionExpanded] = useState(false);
  const requestInProgress = useRef(false);
  
  const caseData = location.state || {};
  const caseType = caseData.caseType || 'thoracic';
  const submissionId = caseData.submissionId;
  const studentSubmission = caseData.submission || defaultSubmissions[caseType];
  
  // Load AI feedback when component mounts
  useEffect(() => {
    const loadAIFeedback = async () => {
      if (!studentSubmission || requestInProgress.current) return;
      
      requestInProgress.current = true;
      setIsLoadingFeedback(true);
      
      try {
        const { data, error } = await supabase.functions.invoke('generate-feedback', {
          body: { caseData: { ...studentSubmission, caseType } }
        });

        if (error) {
          console.error('Error generating feedback:', error);
          toast({
            title: "Error",
            description: "Failed to generate AI feedback. Using default feedback.",
            variant: "destructive",
          });
          setAiFeedback(getFallbackFeedback());
          setAiComparison(getFallbackComparison());
          setAiRecommendations(getFallbackRecommendations());
        } else {
          setAiFeedback(data.feedback || []);
          setAiComparison(data.comparison || { categories: [] });
          setAiRecommendations(data.recommendations || []);
        }
      } catch (error) {
        console.error('Error calling feedback function:', error);
        toast({
          title: "Error", 
          description: "Failed to generate AI feedback. Using default feedback.",
          variant: "destructive",
        });
        setAiFeedback(getFallbackFeedback());
        setAiComparison(getFallbackComparison());
        setAiRecommendations(getFallbackRecommendations());
      } finally {
        setIsLoadingFeedback(false);
        requestInProgress.current = false;
      }
    };

    loadAIFeedback();

    // Cleanup function to reset request status on unmount
    return () => {
      requestInProgress.current = false;
    };
  }, [studentSubmission, caseType]);

  // Scroll to top when feedback is loaded
  useEffect(() => {
    if (!isLoadingFeedback) {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  }, [isLoadingFeedback]);

  const getCaseTitle = (type: string) => {
    switch (type) {
      case 'abdominal':
        return 'Case 1 - Abdomen';
      case 'musculoskeletal':
        return 'Case 1 - Musculoskeletal';
      case 'thoracic':
      default:
        return 'Case 1 - Thorax';
    }
  };
  
  const getFeedbackData = () => aiFeedback.length > 0 ? aiFeedback : getFallbackFeedback();
  const getComparisonData = () => aiComparison.categories.length > 0 ? aiComparison : getFallbackComparison();
  const getRecommendationsData = () => aiRecommendations.length > 0 ? aiRecommendations : getFallbackRecommendations();

  const handleDownloadHTML = async () => {
    try {
      // First save the case submission
      const submissionData = await saveCaseSubmission(studentSubmission as CaseSubmissionData);
      
      if (submissionData) {
        // Then save the feedback linked to the submission
        await saveFeedback({
          caseSubmissionId: submissionData.id,
          aiFeedback: getFeedbackData(),
          personalReview,
          learningRating,
          difficultyRating,
        });
      }
    } catch (error) {
      console.error('Error saving submission and feedback:', error);
    }
    
    // Create HTML content for the feedback report (force refresh)
    const feedbackData = getFeedbackData();
    const comparisonData = getComparisonData();
    const recommendationsData = getRecommendationsData();
    
    const htmlContent = `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="UTF-8">
        <title>Case Feedback Report - ${getCaseTitle(caseType)}</title>
        <style>
          body { 
            font-family: Arial, sans-serif; 
            line-height: 1.6; 
            color: #333; 
            max-width: 800px; 
            margin: 0 auto; 
            padding: 20px;
            word-wrap: break-word;
          }
          .header { 
            text-align: center; 
            margin-bottom: 30px; 
            border: 3px solid #2563eb;
            background: white;
            padding: 20px;
            border-radius: 10px;
          }
          .header h1 { 
            color: #2563eb; 
            margin: 0; 
            font-size: 24px;
          }
          .section { 
            margin-bottom: 25px; 
            break-inside: avoid;
          }
          .section h2 { 
            color: #2563eb; 
            border-bottom: 2px solid #2563eb; 
            padding-bottom: 5px;
            font-size: 20px;
          }
          .section h3 { 
            color: #1e40af; 
            margin-top: 20px;
            font-size: 16px;
          }
          .feedback-item { 
            background: #f8fafc; 
            padding: 15px; 
            margin: 10px 0; 
            border-left: 4px solid #2563eb;
            border-radius: 5px;
          }
          .feedback-title { 
            font-weight: bold; 
            color: #1e40af;
            margin-bottom: 8px;
          }
          .comparison-item { 
            margin: 15px 0; 
            padding: 15px;
            background: #f1f5f9;
            border-radius: 5px;
          }
          .recommendation { 
            background: #ecfdf5; 
            padding: 10px; 
            margin: 8px 0; 
            border-left: 4px solid #10b981;
            border-radius: 3px;
          }
          .submission-content {
            background: #fafafa;
            padding: 15px;
            border-radius: 5px;
            margin: 10px 0;
            white-space: pre-wrap;
            word-break: break-word;
          }
          @media print {
            body { font-size: 12px; }
            .section { page-break-inside: avoid; }
          }
        </style>
      </head>
      <body>
        <div class="header">
          <h1>Dr Watson - the VET.CT Teaching Tool</h1>
          <p><strong>AI Feedback Analysis: ${getCaseTitle(caseType)}</strong></p>
        </div>

        <div class="section">
          <h2>Your Submission</h2>
          <h3>Study Description</h3>
          <div class="submission-content">${studentSubmission.studyDescription || 'No description provided'}</div>
          
          <h3>Findings</h3>
          <div class="submission-content">${studentSubmission.findings || 'No findings provided'}</div>
          
          <h3>Conclusions</h3>
          <div class="submission-content">${studentSubmission.conclusions || 'No conclusions provided'}</div>
          
          <h3>Discussion</h3>
          <div class="submission-content">${studentSubmission.discussion || 'No discussion provided'}</div>
        </div>

        <div class="section">
          <h2>AI Feedback</h2>
          ${feedbackData.map(item => `
            <div class="feedback-item">
              <div class="feedback-title">${item.title}</div>
              <div>${item.content}</div>
            </div>
          `).join('')}
        </div>

        ${comparisonData.categories && comparisonData.categories.length > 0 ? `
        <div class="section">
          <h2>Comparison Analysis</h2>
          ${comparisonData.categories.map(item => `
            <div class="comparison-item">
              <h3>${item.category}</h3>
              <p><strong>Your Report:</strong> ${item.yourReport}</p>
              <p><strong>VET.CT Report:</strong> ${item.vetCtReport}</p>
            </div>
          `).join('')}
        </div>
        ` : ''}

        <div class="section">
          <h2>Recommendations for Improvement</h2>
          ${recommendationsData.map(rec => `
            <div class="recommendation">• ${rec}</div>
          `).join('')}
        </div>

        ${personalReview ? `
        <div class="section">
          <h2>Personal Review</h2>
          <div class="submission-content">${personalReview}</div>
        </div>
        ` : ''}

        <div class="section">
          <h2>Learning Summary</h2>
          <p><strong>Learning Rating:</strong> ${learningRating}/5 stars</p>
          <p><strong>Difficulty Rating:</strong> ${difficultyRating}/5 stars</p>
        </div>
      </body>
      </html>
    `;

    // Create downloadable HTML file
    const blob = new Blob([htmlContent], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    
    // Generate filename with case type and date
    const date = new Date().toISOString().split('T')[0];
    const filename = `VET-CT-Case-Feedback-${caseType}-${date}.html`;
    
    // Create temporary download link and trigger download
    const downloadLink = document.createElement('a');
    downloadLink.href = url;
    downloadLink.download = filename;
    document.body.appendChild(downloadLink);
    downloadLink.click();
    document.body.removeChild(downloadLink);
    
    // Clean up the object URL
    setTimeout(() => URL.revokeObjectURL(url), 1000);

    // Open the HTML in a new window for PDF printing
    const newWindow = window.open('', '_blank');
    if (newWindow) {
      newWindow.document.write(htmlContent);
      newWindow.document.close();
      
      // Show success message for both actions
      toast({
        title: "Report Generated & Downloaded",
        description: "HTML file downloaded automatically. A new window also opened - use Ctrl+P (or Cmd+P) to save as PDF.",
      });
    } else {
      // If popup blocked, still show success for download
      toast({
        title: "Report Downloaded",
        description: "HTML file downloaded successfully. Enable popups to also get the print window.",
      });
    }
  };

  const getBadgeVariant = (type: string) => {
    console.log('Badge type received:', type);
    const normalizedType = type.toLowerCase().trim();
    
    const variant = (() => {
      // Map all possible AI feedback types to the 4 specified variants
      if (normalizedType.includes('positive') || normalizedType.includes('strong') || 
          normalizedType.includes('excellent') || normalizedType.includes('good')) {
        return "excellent";
      }
      if (normalizedType.includes('improvement') || normalizedType.includes('room') ||
          normalizedType.includes('develop') || normalizedType.includes('enhance')) {
        return "improvement";
      }
      if (normalizedType.includes('mixed') || normalizedType.includes('partial') ||
          normalizedType.includes('moderate') || normalizedType.includes('some')) {
        return "mixed";
      }
      if (normalizedType.includes('attention') || normalizedType.includes('concern') ||
          normalizedType.includes('critical') || normalizedType.includes('issue') ||
          normalizedType.includes('error') || normalizedType.includes('missing')) {
        return "attention";
      }
      // Default fallback to improvement for any unrecognized types
      return "improvement";
    })();
    
    console.log('Badge variant mapped to:', variant);
    return variant;
  };

  const getBadgeText = (type: string) => {
    const variant = getBadgeVariant(type);
    
    switch (variant) {
      case "excellent":
        return "+ Excellent";
      case "improvement":
        return "> Room for improvement";
      case "mixed":
        return "∼ Mixed";
      case "attention":
        return "! Needs attention";
      default:
        return "> Room for improvement";
    }
  };

  const StarRating = ({ rating, onRatingChange, label }: { rating: number; onRatingChange: (rating: number) => void; label: string }) => (
    <div className="space-y-2">
      <label className="text-sm font-medium text-foreground">{label}</label>
      <div className="flex space-x-1">
        {[1, 2, 3, 4, 5].map((star) => (
          <button
            key={star}
            onClick={() => onRatingChange(star)}
            className="transition-colors"
          >
            <Star
              className={`w-5 h-5 ${
                star <= rating
                  ? "text-yellow-400 fill-current"
                  : "text-muted-foreground hover:text-yellow-400"
              }`}
            />
          </button>
        ))}
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-primary/5 to-secondary/10">
      <div className="p-8">
        <div className="max-w-6xl mx-auto space-y-8">
          <div className="text-center space-y-4">
            {isLoadingFeedback && (
              <AIAnalysisLoader caseType={getCaseTitle(caseType)} />
            )}
          </div>

        {!isLoadingFeedback && (
          <div>
            {/* VET.CT Teaching Tool Header for PDF */}
            <div className="text-center mb-8">
              <div className="flex justify-center mb-6">
                <VetLogo size="lg" />
              </div>
            </div>

            {/* VET.CT Report Button */}
            <div className="flex flex-col sm:flex-row items-start justify-start gap-4 mb-8">
              {caseType === 'thoracic' && (
                <a 
                  href="https://drive.google.com/file/d/1h-4aVR247th1YF5yQgSxSRbqGq1nmU69/preview?usp=sharing"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-block bg-gray-200 text-gray-700 px-6 py-6 rounded font-semibold hover:bg-gray-300 transition-colors shadow-lg border border-black"
                >
                  📋 View the VET.CT radiology report
                </a>
              )}
              {caseType === 'abdominal' && (
                <a 
                  href="https://drive.google.com/file/d/12ktxQoj7FdBXrOhpZiYZQg1f4Av3Tgse/preview?usp=sharing"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-block bg-gray-200 text-gray-700 px-6 py-6 rounded font-semibold hover:bg-gray-300 transition-colors shadow-lg border border-black"
                >
                  📋 View the VET.CT radiology report
                </a>
              )}
              {caseType === 'musculoskeletal' && (
                <a 
                  href="https://drive.google.com/file/d/1eRvoVrCkRUbd6urNQ2C09dWi8eqK5jSc/preview?usp=sharing"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-block bg-gray-200 text-gray-700 px-6 py-6 rounded font-semibold hover:bg-gray-300 transition-colors shadow-lg border border-black"
                >
                  📋 View the VET.CT radiology report
                </a>
              )}
            </div>

            {/* Feedback Section */}
            <div className="space-y-6 mb-8">
              <div className="text-center space-y-2 mb-6">
                <h2 className="text-3xl font-bold text-primary">AI Feedback Analysis : {getCaseTitle(caseType)}</h2>
              </div>

              <div className="grid gap-6">
                {getFeedbackData().map((feedback: any, index: number) => (
                  <Card key={index} className="shadow-md">
                    <CardHeader className="pb-3">
                      <CardTitle className="text-lg text-primary flex items-center justify-between">
                        <span>
                          {feedback.title}
                        </span>
                        <Badge variant={getBadgeVariant(feedback.type) as any} size="sm">
                          {getBadgeText(feedback.type)}
                        </Badge>
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-sm text-muted-foreground leading-relaxed">{feedback.content}</p>
                    </CardContent>
                  </Card>
                ))}
              </div>

              {/* Comparison Table */}
              <Card className="shadow-md mt-8">
                <CardHeader className="pb-3">
                  <CardTitle className="text-lg text-primary flex items-center">
                    <Trophy className="w-5 h-5 mr-2" />
                    Comparison Table
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead>
                        <tr className="border-b">
                          <th className="text-left py-2 font-semibold text-primary">Category</th>
                          <th className="text-left py-2 font-semibold text-primary">Your Report</th>
                          <th className="text-left py-2 font-semibold text-primary">VET.CT Radiologists' Report</th>
                        </tr>
                      </thead>
                      <tbody>
                        {getComparisonData().categories.map((row: any, index: number) => (
                          <tr key={index} className="border-b">
                            <td className="py-3 font-medium">{row.category}</td>
                            <td className="py-3 text-muted-foreground">{row.yourReport}</td>
                            <td className="py-3 text-muted-foreground">{row.vetCtReport}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </CardContent>
              </Card>

              {/* Final Recommendations */}
              <Card className="shadow-md mt-8">
                <CardHeader className="pb-3">
                  <CardTitle className="text-lg text-primary">Final Recommendations</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {getRecommendationsData().map((recommendation: string, index: number) => (
                      <div key={index} className="flex items-start space-x-3">
                        <div className="flex-shrink-0 w-6 h-6 bg-primary/10 text-primary rounded-full flex items-center justify-center text-sm font-semibold mt-0.5">
                          {index + 1}
                        </div>
                        <div className="text-sm text-muted-foreground leading-relaxed">
                          {recommendation}
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Student Submission Section - Collapsible */}
              <Collapsible open={isSubmissionExpanded} onOpenChange={setIsSubmissionExpanded}>
                <CollapsibleTrigger asChild>
                  <Card className="cursor-pointer hover:bg-gray-50 transition-colors shadow-md bg-gray-100 border-gray-400 mb-4">
                    <CardHeader className="pb-3">
                      <CardTitle className="text-lg text-gray-700 flex items-center justify-between">
                        <span>Your Submission - {getCaseTitle(caseType)}</span>
                        <ChevronDown className={`w-5 h-5 transition-transform ${isSubmissionExpanded ? 'rotate-180' : ''}`} />
                      </CardTitle>
                    </CardHeader>
                  </Card>
                </CollapsibleTrigger>
                
                <CollapsibleContent className="space-y-4 mb-8">
                  <Card className="shadow-md bg-gray-200 border-gray-400">
                    <CardHeader className="pb-3">
                      <CardTitle className="text-base text-primary">Radiographic Study Description</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-sm text-muted-foreground leading-relaxed bg-muted/20 p-3 rounded-lg whitespace-pre-line">
                        {studentSubmission.studyDescription}
                      </div>
                    </CardContent>
                  </Card>

                  <Card className="shadow-md bg-gray-200 border-gray-400">
                    <CardHeader className="pb-3">
                      <CardTitle className="text-base text-primary">Radiographic Findings</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-sm text-muted-foreground leading-relaxed bg-muted/20 p-3 rounded-lg whitespace-pre-line">
                        {studentSubmission.findings}
                      </div>
                    </CardContent>
                  </Card>

                  <Card className="shadow-md bg-gray-200 border-gray-400">
                    <CardHeader className="pb-3">
                      <CardTitle className="text-base text-primary">Conclusions and Differential Diagnoses</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-sm text-muted-foreground leading-relaxed bg-muted/20 p-3 rounded-lg whitespace-pre-line">
                        {studentSubmission.conclusions}
                      </div>
                    </CardContent>
                  </Card>

                  <Card className="shadow-md bg-gray-200 border-gray-400">
                    <CardHeader className="pb-3">
                      <CardTitle className="text-base text-primary">Discussion and Next Steps</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-sm text-muted-foreground leading-relaxed bg-muted/20 p-3 rounded-lg whitespace-pre-line">
                        {studentSubmission.discussion}
                      </div>
                    </CardContent>
                  </Card>
                </CollapsibleContent>
              </Collapsible>

              {/* Personal Review Section */}
              <Card className="shadow-md mt-8">
                <CardHeader className="pb-3">
                  <CardTitle className="text-lg text-primary flex items-center">
                    <FileText className="w-5 h-5 mr-2" />
                    Personal Review
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    <p className="text-sm text-muted-foreground">
                      Take a moment to reflect on this case. What did you learn? What would you do differently next time?
                    </p>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 p-4 bg-muted/20 rounded-lg">
                      <StarRating
                        rating={learningRating}
                        onRatingChange={setLearningRating}
                        label="How useful was this case for learning?"
                      />
                      <StarRating
                        rating={difficultyRating}
                        onRatingChange={setDifficultyRating}
                        label="How hard did you find this case?"
                      />
                    </div>

                    <TextareaWithDictation
                      placeholder="Write your personal reflection on this case here..."
                      value={personalReview}
                      onValueChange={setPersonalReview}
                      className="min-h-32 resize-none"
                    />
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Download Button */}
            <div className="text-right pt-8 space-y-4">
              <Button
                onClick={handleDownloadHTML}
                variant="medical"
                size="lg"
                className="px-6 py-3 font-semibold shadow-lg rounded"
              >
                <Download className="w-5 h-5 mr-2" />
                Save and download your feedback
              </Button>
              
              <div>
                <Button
                  onClick={() => navigate("/")}
                  variant="outline"
                  size="lg"
                  className="px-6 py-3 font-semibold"
                >
                  <ArrowLeft className="w-5 h-5 mr-2" />
                  Explore More Cases
                </Button>
              </div>
            </div>
          </div>
        )}
        </div>
      </div>
    </div>
  );
};

export default AIFeedback;