import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { VetLogo } from "@/components/VetLogo";
import { useCaseSubmissions } from "@/hooks/useCaseSubmissions";
import { useNavigate } from "react-router-dom";
import { Calendar, User, FileText, Star, ExternalLink } from "lucide-react";

const CaseAnalytics = () => {
  const navigate = useNavigate();
  const { getCaseSubmissions } = useCaseSubmissions();
  const [submissions, setSubmissions] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchSubmissions = async () => {
      setLoading(true);
      const data = await getCaseSubmissions();
      setSubmissions(data);
      setLoading(false);
    };

    fetchSubmissions();
  }, []);

  const getCaseTypeVariant = (caseType: string) => {
    switch (caseType) {
      case 'thoracic':
        return 'default';
      case 'abdominal':
        return 'secondary';
      case 'musculoskeletal':
        return 'outline';
      default:
        return 'default';
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-GB', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getCaseStats = () => {
    const stats = {
      total: submissions.length,
      thoracic: submissions.filter(s => s.case_type === 'thoracic').length,
      abdominal: submissions.filter(s => s.case_type === 'abdominal').length,
      musculoskeletal: submissions.filter(s => s.case_type === 'musculoskeletal').length,
      withFeedback: submissions.filter(s => s.case_feedback?.length > 0).length,
    };
    
    return stats;
  };

  const stats = getCaseStats();

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-subtle flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-gray-600">Loading case analytics...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-subtle p-6">
      {/* Header */}
      <div className="flex justify-center mb-8">
        <VetLogo size="md" />
      </div>

      <div className="max-w-6xl mx-auto space-y-6">
        {/* Title */}
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-primary mb-2">Case Analytics Dashboard</h1>
          <p className="text-gray-600">Analysis of student submissions and feedback</p>
        </div>

        {/* Stats Overview */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-8">
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-primary">{stats.total}</div>
              <div className="text-sm text-gray-600">Total Submissions</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-blue-600">{stats.thoracic}</div>
              <div className="text-sm text-gray-600">Thoracic Cases</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-green-600">{stats.abdominal}</div>
              <div className="text-sm text-gray-600">Abdominal Cases</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-purple-600">{stats.musculoskeletal}</div>
              <div className="text-sm text-gray-600">Musculoskeletal</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-orange-600">{stats.withFeedback}</div>
              <div className="text-sm text-gray-600">With Feedback</div>
            </CardContent>
          </Card>
        </div>

        {/* Submissions List */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileText className="w-5 h-5" />
              Recent Submissions
            </CardTitle>
          </CardHeader>
          <CardContent>
            {submissions.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                No submissions found. Students haven't submitted any cases yet.
              </div>
            ) : (
              <div className="space-y-4">
                {submissions.map((submission) => (
                  <div key={submission.id} className="border rounded-lg p-4 hover:bg-gray-50 transition-colors">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <Badge variant={getCaseTypeVariant(submission.case_type)}>
                            {submission.case_type}
                          </Badge>
                          <h3 className="font-semibold text-primary">{submission.case_title}</h3>
                        </div>
                        
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm text-gray-600 mb-3">
                          <div className="flex items-center gap-2">
                            <User className="w-4 h-4" />
                            <span><strong>Signalment:</strong> {submission.signalment}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <Calendar className="w-4 h-4" />
                            <span><strong>Submitted:</strong> {formatDate(submission.created_at)}</span>
                          </div>
                        </div>

                        <div className="text-sm text-gray-700 mb-2">
                          <strong>History:</strong> {submission.history}
                        </div>

                        {submission.image_links && submission.image_links.length > 0 && (
                          <div className="mb-2">
                            <strong className="text-sm">Images:</strong>
                            {submission.image_links.map((link: string, index: number) => (
                              <a 
                                key={index}
                                href={link} 
                                target="_blank" 
                                rel="noopener noreferrer"
                                className="ml-2 text-primary hover:text-primary/80 underline text-sm inline-flex items-center gap-1"
                              >
                                View Image {index + 1} <ExternalLink className="w-3 h-3" />
                              </a>
                            ))}
                          </div>
                        )}

                        {/* Show feedback info if available */}
                        {submission.case_feedback?.length > 0 && (
                          <div className="flex items-center gap-4 mt-3">
                            <Badge variant="outline" className="text-green-600 border-green-600">
                              Feedback Completed
                            </Badge>
                            {submission.case_feedback[0].learning_rating && (
                              <div className="flex items-center gap-1">
                                <Star className="w-4 h-4 text-yellow-500" />
                                <span className="text-sm">Learning: {submission.case_feedback[0].learning_rating}/5</span>
                              </div>
                            )}
                            {submission.case_feedback[0].difficulty_rating && (
                              <div className="flex items-center gap-1">
                                <Star className="w-4 h-4 text-orange-500" />
                                <span className="text-sm">Difficulty: {submission.case_feedback[0].difficulty_rating}/5</span>
                              </div>
                            )}
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Collapsible submission details */}
                    <details className="mt-3">
                      <summary className="cursor-pointer text-sm font-medium text-primary hover:text-primary/80">
                        View Submission Details
                      </summary>
                      <div className="mt-3 space-y-3 text-sm bg-gray-50 p-4 rounded-lg">
                        <div>
                          <strong>Study Description:</strong>
                          <p className="mt-1">{submission.study_description || "Not provided"}</p>
                        </div>
                        <div>
                          <strong>Findings:</strong>
                          <p className="mt-1">{submission.findings || "Not provided"}</p>
                        </div>
                        <div>
                          <strong>Conclusions:</strong>
                          <p className="mt-1">{submission.conclusions || "Not provided"}</p>
                        </div>
                        <div>
                          <strong>Discussion:</strong>
                          <p className="mt-1">{submission.discussion || "Not provided"}</p>
                        </div>
                        {submission.case_feedback?.length > 0 && submission.case_feedback[0].personal_review && (
                          <div>
                            <strong>Personal Review:</strong>
                            <p className="mt-1">{submission.case_feedback[0].personal_review}</p>
                          </div>
                        )}
                      </div>
                    </details>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Back Button */}
        <div className="flex justify-center">
          <Button
            variant="outline"
            onClick={() => navigate('/')}
            className="px-8"
          >
            Back to Home
          </Button>
        </div>
      </div>
    </div>
  );
};

export default CaseAnalytics;