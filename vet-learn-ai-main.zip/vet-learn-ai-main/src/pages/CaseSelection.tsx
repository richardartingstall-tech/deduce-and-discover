import { Button } from "@/components/ui/button";
import { VetLogo } from "@/components/VetLogo";
import { PageHeader } from "@/components/ui/page-header";
import { useNavigate } from "react-router-dom";

const CaseSelection = () => {
  const navigate = useNavigate();

  const handleCaseClick = (caseType: string) => {
    if (caseType === 'msk') {
      navigate('/musculoskeletal-case');
    } else if (caseType === 'thoracic') {
      navigate('/thoracic-case');
    } else if (caseType === 'abdominal') {
      navigate('/abdominal-case');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-subtle flex flex-col">
      <div className="p-6 flex-1 flex flex-col">
        {/* Header with Logo */}
        <div className="flex justify-center mb-8">
          <VetLogo size="lg" />
        </div>

        {/* Page Title */}
        <PageHeader className="max-w-2xl text-lg whitespace-nowrap">What type of cases would you like to explore today?</PageHeader>

        {/* Case Selection Cards */}
        <div className="flex-1 flex items-center justify-center">
          <div className="w-full max-w-2xl mx-auto space-y-6 flex flex-col items-center">
            <Button
              variant="medical"
              size="case"
              onClick={() => handleCaseClick('msk')}
              className="w-96 rounded-full"
            >
              Musculoskeletal Cases
            </Button>

            <Button
              variant="medical"
              size="case"
              onClick={() => handleCaseClick('thoracic')}
              className="w-96 rounded-full"
            >
              Thoracic Cases
            </Button>

            <Button
              variant="medical"
              size="case"
              onClick={() => handleCaseClick('abdominal')}
              className="w-96 rounded-full"
            >
              Abdominal Cases
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CaseSelection;