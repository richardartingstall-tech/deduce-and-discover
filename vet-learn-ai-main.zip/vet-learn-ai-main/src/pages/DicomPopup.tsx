import { DicomPopupWrapper } from "@/components/DicomPopupWrapper";
import { useEffect, useState } from "react";

const DicomPopup = () => {
  const [dicomUrl, setDicomUrl] = useState<string>("");

  useEffect(() => {
    // Get the URL from the query parameters
    const params = new URLSearchParams(window.location.search);
    const url = params.get('url');
    
    if (url) {
      setDicomUrl(decodeURIComponent(url));
    } else {
      // If no URL provided, show error
      console.error('No DICOM URL provided');
    }
  }, []);

  if (!dicomUrl) {
    return (
      <div className="h-screen w-full bg-white flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-xl font-semibold text-red-600 mb-2">Error</h1>
          <p className="text-gray-600">No DICOM URL provided</p>
        </div>
      </div>
    );
  }

  return <DicomPopupWrapper dicomUrl={dicomUrl} />;
};

export default DicomPopup;