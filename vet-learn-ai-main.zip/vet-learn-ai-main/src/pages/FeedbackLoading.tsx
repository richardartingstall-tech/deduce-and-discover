import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Cog, Dog } from "lucide-react";

const FeedbackLoading = () => {
  const navigate = useNavigate();
  const [sniffCount, setSniffCount] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setSniffCount(prev => prev + 1);
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const timer = setTimeout(() => {
      navigate('/ai-feedback', { 
        state: window.history.state?.usr || null 
      });
    }, 5000);

    return () => clearTimeout(timer);
  }, [navigate]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-primary/5 to-secondary/10 flex items-center justify-center">
      <div className="text-center space-y-8 p-8">
        {/* Rotating Cog */}
        <div className="relative flex justify-center">
          <Cog 
            className="w-24 h-24 text-primary animate-spin" 
            strokeWidth={1.5}
          />
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="w-8 h-8 bg-primary/10 rounded-full animate-pulse" />
          </div>
        </div>

        {/* Animated Dog */}
        <div className="flex justify-center">
          <div className="relative">
            <Dog 
              className={`w-16 h-16 text-secondary transition-all duration-500 ${
                sniffCount % 2 === 0 ? 'scale-110 rotate-2' : 'scale-100 -rotate-1'
              }`}
              strokeWidth={1.5}
            />
            {/* Sniff particles animation */}
            <div className="absolute -right-2 -top-1">
              {[...Array(3)].map((_, i) => (
                <div
                  key={i}
                  className={`absolute w-1 h-1 bg-primary/40 rounded-full animate-ping`}
                  style={{
                    animationDelay: `${i * 0.2}s`,
                    right: `${i * 4}px`,
                    top: `${i * 2}px`,
                  }}
                />
              ))}
            </div>
          </div>
        </div>

        {/* Loading Text */}
        <div className="space-y-2">
          <h1 className="text-2xl font-semibold text-primary">
            Gathering your feedback
          </h1>
          <p className="text-muted-foreground text-lg">
            Our AI is analyzing your responses...
          </p>
        </div>

        {/* Loading Dots */}
        <div className="flex justify-center space-x-2">
          {[...Array(3)].map((_, i) => (
            <div
              key={i}
              className="w-3 h-3 bg-primary rounded-full animate-bounce"
              style={{ animationDelay: `${i * 0.2}s` }}
            />
          ))}
        </div>
      </div>
    </div>
  );
};

export default FeedbackLoading;