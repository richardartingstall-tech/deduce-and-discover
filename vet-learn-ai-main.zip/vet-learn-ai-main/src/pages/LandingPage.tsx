import { Button } from "@/components/ui/button";
import { Search } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { VetLogo } from "@/components/VetLogo";

const LandingPage = () => {
  const navigate = useNavigate();

  const handleGetStarted = () => {
    navigate("/cases");
  };

  return (
    <div className="min-h-screen bg-gradient-subtle flex flex-col items-center justify-center p-6">
      <div className="flex flex-col items-center space-y-8 max-w-4xl mx-auto text-center">
        
        {/* Title Box */}
        <div className="flex flex-col items-center space-y-6">
          <VetLogo size="lg" />
        </div>

        {/* Large Magnifying Glass */}
        <div className="my-12">
          <Search 
            size={120} 
            className="text-primary/60 hover:text-primary transition-colors duration-300" 
            strokeWidth={2}
          />
        </div>

        {/* Get Started Button */}
        <Button
          onClick={handleGetStarted}
          variant="medical"
          size="lg"
          className="text-2xl px-16 py-6 font-semibold shadow-medical hover:shadow-lg transition-all duration-300 rounded-full"
        >
          Get Started
        </Button>

        {/* Subtitle */}
        <p className="text-gray-600 text-lg max-w-2xl">
          Welcome to Dr Watson, your AI-powered teaching companion for veterinary radiology case studies.
        </p>
      </div>
    </div>
  );
};

export default LandingPage;