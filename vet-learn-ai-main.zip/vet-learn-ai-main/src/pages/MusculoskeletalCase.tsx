import { Button } from "@/components/ui/button";
import { VetLogo } from "@/components/VetLogo";
import { PageHeader } from "@/components/ui/page-header";
import { TextareaWithDictation } from "@/components/ui/textarea-with-dictation";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { DicomViewerModal } from "@/components/DicomViewerModal";
import { useState } from "react";
import { openDicomPopup } from "@/lib/openDicomPopup";
import { useNavigate } from "react-router-dom";
import { X, ArrowLeft, Key } from "lucide-react";
import { useCaseSubmissions } from "@/hooks/useCaseSubmissions";

const MusculoskeletalCase = () => {
  const navigate = useNavigate();
  const { submissionCount, submissionLimit, isLimitReached, getRemainingSubmissions } = useCaseSubmissions();
  const [showStudyDescriptionTips, setShowStudyDescriptionTips] = useState(false);
  const [showFindingsTips, setShowFindingsTips] = useState(false);
  const [showConclusionsTips, setShowConclusionsTips] = useState(false);
  const [showDiscussionTips, setShowDiscussionTips] = useState(false);
  const [showDicomViewer, setShowDicomViewer] = useState(false);
  const dicomUrl = "https://viewer.vet-ct.com/viewer/DirectLink.aspx?cp=z%2FSXDK9y2B2sO42maad111koE5o0NpH2ixERMvFMeeUPDCYUWYkoqPyPqzS%2BKjQEdFzncY3YRulT%0D%0AueoXOPvWtkyvA4nf0slss9frfpAcmbR%2Fihinsj52rO6CxspH%2BNjj%0D%0A&issue_key=ANON-1649&user=richard-artingstall" as const;
  
  // State for text area contents
  const [studyDescription, setStudyDescription] = useState("");
  const [radiographicFindings, setRadiographicFindings] = useState("");
  const [conclusions, setConclusions] = useState("");
  const [discussion, setDiscussion] = useState("");

  const handleSignalmentClick = () => {
    // Placeholder for signalment details
    console.log("Opening signalment and history details");
  };

  const handlePDFClick = () => {
    // Placeholder for PDF images
    console.log("Opening PDF images");
  };

  const loadDemonstrationSubmission = () => {
    setStudyDescription("a. The radiographic study consists of eight views of the canine limb: lateral views of the right and left tarsocrural joints, lateral views of the right and left cubital joints, dorsoplantar and lateral views of the right and left genual joints.\n\nb. The study quality, technique, and positioning is adequate for interpretation.\n\nc. The views are correctly labeled and displayed, and the choice of views was appropriate given the patient's history of lameness. It may be beneficial to also do an abdominal series given the patient's range of symptomology and exposure to possible foreign material that could cause an intestinal perforation such as bones in the raw diet.");
    
    setRadiographicFindings("a. There are open physes notes in all the long bones pictured. The medial coronoid process and olecranon process are not attached.\n\nThe left and right humerus are smoothly marginated with intact cortices. The right and left radius are smoothly marginated with intact cortices. There is foreign material present at the distal aspect of the right radius consistent with an indwelling IV catheter.\n\nThe right and left ulnas are smoothly marginated with intact cortices. The tibia and fibula appear unremarkable, but an orthogonal view would be necessary to be sure.\n\nThere is mild soft tissue swelling around the tarsal joints on the right limb. The distal tarsal bones, metatarsals and phalanges appear normal.\n\nThe left and right stifle joints show evidence of increased soft tissue opacity surrounding the joints, and the popliteal lymph nodes are prominent. There is some bony proliferation on the articular aspect of the lateral condyle of the left femur with scalloped edges and clear margins");
    
    setConclusions("a. Proliferative mineral opacity distal left femur.\n\nb. Prominent popliteal lymph nodes.\n\nc. Soft tissue swelling right tarsal and stifle joint and left stifle joint.\n\nd. Open physes – appropriate for age of patient");
    
    setDiscussion("a. This patient's clinical signs and radiographic findings align with differentials such as septic arthritis, nutritional/metabolic related disorders, hypertrophic osteodystrophy, or osteochondrosis.\n\nSeptic arthritis is the top differential in this patient due to the systemic signs involved such as gastrointestinal upset, pyrexia, and lameness.\n\nThe raw food diet brings into considerations whether the diet that this puppy and her littermates are receiving is complete and balanced. Raw homemade diets are often very protein heavy and may lack some key ingredients for growing puppies which could lead to a nutritional/metabolic disorder such as nutritional secondary hyperparathyroidism.\n\nHowever, the pyrexia does not fit with this differential, nor does the death of other littermates.\n\nAt this point, further imaging is not indicated, but systemic diagnostic procedures such as bloodwork and arthrocentesis may be indicated to rule in/out septic arthritis and target antimicrobial treatments.\n\nSupportive care is pertinent for survival and will include hydration, aggressive IV antibiotics, and continuous monitoring");
  };

  return (
    <div className="min-h-screen bg-gradient-subtle p-6 flex flex-col">
      {/* Header with Logo */}
      <div className="flex justify-center mb-8">
        <VetLogo size="md" />
      </div>

      {/* Main Content */}
      <div className="flex-1 flex items-center justify-center relative">
        <div className="w-full max-w-4xl mx-auto space-y-6">
          
          {/* Signalment and History Section */}
          <div className="w-full bg-white border-2 border-gray-300 rounded-2xl p-6 shadow-card">
            <h2 className="text-xl font-semibold text-primary mb-4 border-b border-gray-200 pb-2">
              Case 1 - Musculoskeletal
            </h2>
            <div className="space-y-4 text-gray-700">
              <div className="bg-gray-50 p-4 rounded-lg">
                <h3 className="font-medium text-primary mb-2">Signalment:</h3>
                <p className="text-sm leading-relaxed">
                  3 month old, Female Entire, Canine - Boxer
                </p>
              </div>
              <div className="bg-gray-50 p-4 rounded-lg">
                <h3 className="font-medium text-primary mb-2">History:</h3>
                <p className="text-sm leading-relaxed">
                  History of pyrexia, lameness and diarrhea. Two littermates have died with similar symptoms. They are fed a raw diet.
                </p>
              </div>
              <div className="bg-gray-50 p-4 rounded-lg">
                <h3 className="font-medium text-primary mb-2">View images here:</h3>
                <button
                  onClick={() => openDicomPopup(dicomUrl)}
                  className="text-primary hover:text-primary/80 underline hover:no-underline transition-colors text-sm cursor-pointer bg-transparent border-none p-0"
                >
                  Click here to view radiographic images
                </button>
              </div>
            </div>
          </div>

          {/* Assessment Instruction Box */}
          <div className="flex flex-col items-center gap-3">
            <div className="bg-white text-primary px-8 py-4 rounded-lg shadow-lg">
              <h3 className="text-lg font-semibold text-center">
                Submit your radiographic assessment below
              </h3>
            </div>
            <Button
              variant="outline"
              size="sm"
              className="bg-green-500 text-white border-green-500 hover:bg-green-600 hover:border-green-600 px-4 py-2 text-sm font-medium rounded-full"
              onClick={loadDemonstrationSubmission}
            >
              For demo - click here to see a real student submission
            </Button>
          </div>

          {/* Radiographic Input Sections */}
          <Card className="w-full">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg text-primary flex-1 pr-4">Radiographic Study Description</CardTitle>
                <div className="relative">
                  <Button
                    variant="tips"
                    size="sm"
                    className="text-xs"
                    onClick={() => setShowStudyDescriptionTips(!showStudyDescriptionTips)}
                  >
                    top tips
                  </Button>
                  
                  {/* Study Description Tips Popup */}
                  {showStudyDescriptionTips && (
                     <div className="absolute top-full right-0 mt-2 w-96 bg-tips-yellow border-2 border-gray-200 rounded-2xl p-6 shadow-medical z-10">
                      <div className="space-y-4">
                        <h3 className="text-lg font-semibold text-primary mb-4">
                          Radiographic Study Description Tips
                        </h3>
                        <div className="space-y-3 text-gray-700">
                          <ul className="text-sm leading-relaxed space-y-2">
                            <li>
                              <strong>Patient & Location:</strong> Start by clearly stating the species, number of views and anatomic area being examined. <span className="italic">e.g., "Three radiographs of the canine thorax," or "Four radiographs of the feline stifle."</span>
                            </li>
                            <li>
                              <strong>Views:</strong> List the specific radiographic views included in the study. <span className="italic">e.g., "Left lateral and ventrodorsal views of the thorax."</span>
                            </li>
                            <li>
                              <strong>Anatomic Margins:</strong> Ensure the radiograph includes the full area of interest. <span className="italic">e.g., "The entire limb is included from the carpus to the elbow."</span>
                            </li>
                            <li>
                              <strong>Collimation:</strong> Comment on whether the x-ray beam was properly restricted, or "coned down," to the area of interest. <span className="italic">e.g., "The study is well-collimated to the abdomen."</span>
                            </li>
                            <li>
                              <strong>Quality & Exposure:</strong> Assess the image for proper exposure (not too dark or too light) and positioning. <span className="italic">e.g., "Good technical quality with appropriate exposure," or "Slightly underexposed."</span>
                            </li>
                          </ul>
                        </div>
                        <div className="flex gap-2 mt-4">
                          <Button
                            variant="medical"
                            size="sm"
                            className="flex-1"
                            onClick={() => window.open('https://education.vet-ct.com/unlock/FMPMDd1', '_blank')}
                          >
                            Learn more here within our LMS
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => setShowStudyDescriptionTips(false)}
                          >
                            <X size={16} />
                          </Button>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <TextareaWithDictation 
                placeholder="Enter your description..."
                className={`resize-none italic text-lg leading-relaxed ${studyDescription ? 'min-h-[200px]' : 'min-h-[120px]'}`}
                value={studyDescription}
                onValueChange={setStudyDescription}
              />
            </CardContent>
          </Card>

          <Card className="w-full">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg text-primary flex-1 pr-4">Radiographic Findings</CardTitle>
                <div className="relative">
                  <Button
                    variant="tips"
                    size="sm"
                    className="text-xs"
                    onClick={() => setShowFindingsTips(!showFindingsTips)}
                  >
                    top tips
                  </Button>
                  
                  {/* Radiographic Findings Tips Popup */}
                  {showFindingsTips && (
                     <div className="absolute top-full right-0 mt-2 w-96 bg-tips-yellow border-2 border-gray-200 rounded-2xl p-6 shadow-medical z-10">
                       <div className="space-y-4">
                         <h3 className="text-lg font-semibold text-primary mb-4">
                           Systematic Radiographic Evaluation Tips 🐾
                         </h3>
                         <div className="space-y-3 text-gray-700">
                           <ul className="text-sm leading-relaxed space-y-2">
                             <li>
                               <strong>Go Outside-In:</strong> Start with the periphery (soft tissues, skin) before moving to the core structures.
                             </li>
                             <li>
                               <strong>System by System:</strong> Evaluate each organ system individually and in a consistent order (e.g., heart, lungs, vessels, bones).
                             </li>
                             <li>
                               <strong>Use the Roentgen Signs:</strong> Describe every finding using the official "radiographic language" of <strong>size, shape, opacity, location, margination, and number.</strong>
                             </li>
                             <li>
                               <strong>Don't Forget "Review Areas":</strong> Always check common blind spots like the spine, sternum, and soft tissues at the edges.
                             </li>
                             <li>
                               <strong>Compare Orthogonal Views:</strong> Use both views (e.g., lateral and ventrodorsal) to confirm findings and pinpoint the exact location of abnormalities.
                             </li>
                           </ul>
                         </div>
                        <div className="flex gap-2 mt-4">
                          <Button
                            variant="medical"
                            size="sm"
                            className="flex-1"
                            onClick={() => window.open('https://education.vet-ct.com/unlock/FMPMDd1', '_blank')}
                          >
                            Learn more here within our LMS
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => setShowFindingsTips(false)}
                          >
                            <X size={16} />
                          </Button>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <TextareaWithDictation 
                placeholder="Enter your findings..."
                className={`resize-none italic text-lg leading-relaxed ${radiographicFindings ? 'min-h-[300px]' : 'min-h-[120px]'}`}
                value={radiographicFindings}
                onValueChange={setRadiographicFindings}
              />
            </CardContent>
          </Card>

          <Card className="w-full">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg text-primary flex-1 pr-4">Conclusions and Differential Diagnoses</CardTitle>
                <div className="relative">
                  <Button
                    variant="tips"
                    size="sm"
                    className="text-xs"
                    onClick={() => setShowConclusionsTips(!showConclusionsTips)}
                  >
                    top tips
                  </Button>
                  
                  {/* Radiographic Conclusions Tips Popup */}
                  {showConclusionsTips && (
                     <div className="absolute top-full right-0 mt-2 w-96 bg-tips-yellow border-2 border-gray-200 rounded-2xl p-6 shadow-medical z-10">
                      <div className="space-y-4">
                         <h3 className="text-lg font-semibold text-primary mb-4">
                           Differential Diagnoses Tips 🐾
                         </h3>
                         <div className="space-y-3 text-gray-700">
                           <ul className="text-sm leading-relaxed space-y-2">
                             <li>
                               <strong>Use the DAMNITV Scheme:</strong> Use this mnemonic to build a comprehensive list of potential causes: <strong>D</strong>egenerative, <strong>A</strong>nomalous, <strong>M</strong>etabolic, <strong>N</strong>eoplasia, <strong>I</strong>nflammatory/Infectious, <strong>T</strong>raumatic/Toxic, <strong>V</strong>ascular.
                             </li>
                             <li>
                               <strong>Prioritize the List:</strong> Rank your differentials from most to least likely based on the patient's signalment (age, breed) and your specific radiographic findings.
                             </li>
                             <li>
                               <strong>Support with Evidence:</strong> Briefly state <strong>why</strong> each diagnosis is on your list, using the radiographic findings you described.
                             </li>
                             <li>
                               <strong>Acknowledge Uncertainty:</strong> Don't be afraid to state that a definitive diagnosis is not possible from the radiographs alone. This demonstrates an accurate understanding of the limitations of the imaging modality.
                             </li>
                           </ul>
                         </div>
                        <div className="flex gap-2 mt-4">
                          <Button
                            variant="medical"
                            size="sm"
                            className="flex-1"
                            onClick={() => window.open('https://education.vet-ct.com/unlock/FMPMDd1', '_blank')}
                          >
                            Learn more here within our LMS
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => setShowConclusionsTips(false)}
                          >
                            <X size={16} />
                          </Button>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <TextareaWithDictation 
                placeholder="Enter your differential diagnoses and conclusions..."
                className={`resize-none italic text-lg leading-relaxed ${conclusions ? 'min-h-[180px]' : 'min-h-[120px]'}`}
                value={conclusions}
                onValueChange={setConclusions}
              />
            </CardContent>
          </Card>

          <Card className="w-full">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg text-primary flex-1 pr-4">Discussion and Next Steps</CardTitle>
                <div className="relative">
                  <Button
                    variant="tips"
                    size="sm"
                    className="text-xs"
                    onClick={() => setShowDiscussionTips(!showDiscussionTips)}
                  >
                    top tips
                  </Button>
                  
                  {/* Radiographic Discussion Tips Popup */}
                  {showDiscussionTips && (
                    <div className="absolute top-full right-0 mt-2 w-96 bg-tips-yellow border-2 border-gray-200 rounded-2xl p-6 shadow-medical z-10">
                      <div className="space-y-4">
                         <h3 className="text-lg font-semibold text-primary mb-4">
                           Radiographic Discussion and Next Steps Tips 🐾
                         </h3>
                          <div className="space-y-3 text-gray-700">
                            <ul className="text-sm leading-relaxed space-y-2">
                              <li>
                                <strong>Summarize Your Conclusion:</strong> Briefly restate your most likely diagnosis and the key findings that support it.
                              </li>
                              <li>
                                <strong>Justify Your Recommendations:</strong> Explain <em>why</em> a specific test is the logical next step. Connect it directly to your top differentials.
                              </li>
                              <li>
                                <strong>Consider Other Modalities:</strong> Recommend other imaging tests (e.g., ultrasound, CT, MRI) to better characterize a lesion or rule out a diagnosis.
                              </li>
                              <li>
                                <strong>Include Non-Imaging Tests:</strong> Don't forget to recommend non-imaging diagnostics like blood work, urinalysis, or a fine-needle aspirate/biopsy to reach a definitive diagnosis.
                              </li>
                              <li>
                                <strong>Acknowledge Limitations:</strong> Clearly state what the radiographs <em>cannot</em> definitively diagnose, highlighting the need for further testing.
                              </li>
                            </ul>
                          </div>
                        <div className="flex gap-2 mt-4">
                          <Button
                            variant="medical"
                            size="sm"
                            className="flex-1"
                            onClick={() => window.open('https://education.vet-ct.com/unlock/FMPMDd1', '_blank')}
                          >
                            Learn more here within our LMS
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => setShowDiscussionTips(false)}
                          >
                            <X size={16} />
                          </Button>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <TextareaWithDictation 
                placeholder="Enter your discussion and next steps..."
                className={`resize-none italic text-lg leading-relaxed ${discussion ? 'min-h-[350px]' : 'min-h-[120px]'}`}
                value={discussion}
                onValueChange={setDiscussion}
              />
            </CardContent>
          </Card>

          {/* Submission Status */}
          <div className="text-center mt-12 mb-4">
            <p className="text-sm text-muted-foreground">
              Case submissions: {submissionCount}/{submissionLimit}
              {isLimitReached && (
                <span className="block text-destructive mt-1">
                  Session limit reached. Refresh browser to start new session.
                </span>
              )}
            </p>
          </div>

          {/* Submit Button */}
          <div className="flex justify-end mt-4">
            <Button
              variant="medical"
              size="default"
              className="px-6 py-3 rounded-lg text-base border border-black"
              disabled={isLimitReached}
              onClick={() => {
                navigate('/ai-feedback', {
                  state: {
                    caseType: 'musculoskeletal',
                    submission: {
                      caseType: "musculoskeletal",
                      caseTitle: "Case 1 - Musculoskeletal",
                      signalment: "3 month old, Female Entire, Canine - Boxer",
                      history: "History of pyrexia, lameness and diarrhea. Two littermates have died with similar symptoms. They are fed a raw diet.",
                      imageLinks: ["https://viewer.vet-ct.com/viewer/DirectLink.aspx?cp=z%2FSXDK9y2B2sO42maad111koE5o0NpH2ixERMvFMeeUPDCYUWYkoqPyPqzS%2BKjQEdFzncY3YRulT%0D%0AueoXOPvWtkyvA4nf0slss9frfpAcmbR%2Fihinsj52rO6CxspH%2BNjj%0D%0A&issue_key=ANON-1649&user=richard-artingstall"],
                      studyDescription,
                      findings: radiographicFindings,
                      conclusions,
                      discussion,
                    }
                  }
                });
              }}
            >
              {isLimitReached ? "Session Limit Reached" : "Submit your case for personalized feedback"}
            </Button>
          </div>

          {/* Back Button */}
          <div className="flex justify-center mt-8">
            <Button
              variant="outline"
              onClick={() => navigate('/')}
              className="px-8 rounded-full"
            >
              <ArrowLeft size={16} className="mr-2" />
              Back to Case Selection
            </Button>
          </div>
        </div>
      </div>

      {/* DICOM Viewer Modal */}
      <DicomViewerModal
        isOpen={showDicomViewer}
        onClose={() => setShowDicomViewer(false)}
        viewerUrl={dicomUrl}
        caseTitle="Musculoskeletal Case"
      />
    </div>
  );
};

export default MusculoskeletalCase;