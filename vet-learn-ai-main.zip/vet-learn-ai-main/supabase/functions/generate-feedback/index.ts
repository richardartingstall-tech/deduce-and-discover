import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// VET.CT Radiologists Report data for different case types
// NOTE: This data has been moved to the database in the case_templates table
// and is now fetched dynamically. This constant is kept for reference only.
/*
const GROUND_TRUTH_DATA = {
  thoracic: `
VET.CT RADIOLOGISTS REPORT - THORACIC CASE:
Case: 12 year old Female Neutered Canine Fox Terrier with unproductive cough and progressive lethargy

Radiographic Findings:
- Soft tissue opacity in right cranial lung lobe region
- Good collimation including entire diaphragm
- No artifacts, properly labeled radiographs

Correct Diagnosis: Primary lung adenocarcinoma
Key Teaching Points:
- Lung masses in older dogs are often malignant
- Right cranial lung lobe is a common location
- Differential diagnoses include lung lobe torsion, aspiration pneumonia
- Thoracic ultrasound and fine needle aspiration recommended for definitive diagnosis
- Staging workup including abdominal ultrasound and chest CT indicated
`,

  abdominal: `
VET.CT RADIOLOGISTS REPORT - ABDOMINAL CASE:
Standard abdominal case report for educational feedback

Key Learning Objectives:
- Systematic approach to abdominal radiograph interpretation
- Recognition of normal vs abnormal organ silhouettes
- Understanding of contrast studies and their indications
- Evaluation of gastrointestinal patterns and foreign bodies
`,

  musculoskeletal: `
VET.CT RADIOLOGISTS REPORT - MUSCULOSKELETAL CASE:
Case: 3-month-old Female Entire Canine Boxer with pyrexia, lameness, and diarrhea

Clinical History:
Referred for investigation of pyrexia and lameness. Two littermates died following lameness, pyrexia, anaemia and seizure. All puppies fed raw meat and raw tripe diet with no complete food. Left shift neutrophilia, moderate anaemia, prolonged coagulation times. Grade I/VI heart murmur, temp 40°C, pyrexic for one week, joint effusions and pain.

Technical Comments:
Pelvis: left lateral and ventrodorsal views
Left stifle: lateral and craniocaudal views
Right stifle: lateral and craniocaudal views  
Left elbow: lateral view
Right elbow: lateral view
Left pes: lateral view
Right pes: lateral view

Diagnostic Interpretation:

PELVIS:
The coxofemoral joints are within normal limits. Moderate soft tissue swelling of the stifle joints, left greater than the right is included in the view collimation. Within the included lumbar spine there is mild irregularity of the ventral margins of the L3, L4 and L5 vertebral bodies. There is a mild decrease in opacity of these vertebral bodies.

LEFT STIFLE:
Severe soft tissue swelling associated with the stifle joint space. Irregular bone lysis is noted on the medial and lateral aspects of the femoral condyles, trochlear ridge of the femur and proximal patella. Moderate enlargement of the popliteal lymph node. Mild soft tissue swelling noted in the included tarsus on the craniocaudal stifle view.

RIGHT STIFLE:
Very similar changes to the left comprising severe soft tissue swelling and multifocal bone lysis. Right popliteal lymph node enlargement is again noted.

LEFT ELBOW:
Moderate soft tissue swelling surrounding the elbow joint. Mild irregularity of the margins of the proximal epiphysis of the ulna. This irregularity is considered excessive for normal epiphyseal growth. The bone margins of the epiphysis of the medial epicondyle are also mildly irregular.

RIGHT ELBOW:
Similar to the left moderate soft tissue swelling of the right elbow. Irregular osseous margins of the proximal epiphysis of the ulna and epiphysis of the medial epicondyle.

LEFT PES:
Mild soft tissue swelling of the tarsocrural joint. The mild irregularity of the caudal tibial metaphysis is thought to be the result of the normal cut-back zone.

RIGHT PES:
Same findings as the left.

Conclusions:
- Mild to severe joint effusion of the stifle, elbow and tarsal joints bilaterally
- Concurrent aggressive bone changes in both stifle joints and suspected within both elbow joints
- Primary differential: Septic polyarthritis given clinical history and patient age
- Bilateral popliteal lymphadenopathy most likely reactive inflammatory change secondary to stifle joint disease
- Possible L3, L4 and L5 vertebral osteomyelitis
- Normal evaluation of the coxofemoral joints

Key Teaching Points:
- Systematic approach to musculoskeletal radiograph interpretation including all visible joints and bones
- Recognition of aggressive bone lysis patterns in septic arthritis
- Correlation of radiographic findings with clinical history and signalment
- Understanding of joint effusion radiographic signs and soft tissue swelling
- Evaluation of lymph nodes in inflammatory conditions
- Recognition of normal vs abnormal epiphyseal margins in young animals
- Importance of bilateral comparison in polyarticular disease
- Understanding of cut-back zone appearance in growing animals
`
};
*/

// Helper function to parse OpenAI response and structure feedback
function parseFeedbackResponse(content: string) {
  try {
    // Try to parse as JSON first
    const parsed = JSON.parse(content);
    return parsed;
  } catch {
    // Fallback: parse text-based response
    const sections = content.split(/##|###|\*\*/).filter(s => s.trim());
    
    const feedback = [];
    const comparison = { categories: [] };
    const recommendations = [];
    
    for (const section of sections) {
      const text = section.trim();
      if (text.toLowerCase().includes('positive') || text.toLowerCase().includes('correct')) {
        feedback.push({ title: 'Positive Feedback', type: 'positive', content: text });
      } else if (text.toLowerCase().includes('improvement') || text.toLowerCase().includes('consider')) {
        feedback.push({ title: 'Areas for Improvement', type: 'improvement', content: text });
      } else if (text.toLowerCase().includes('recommend')) {
        recommendations.push(text);
      } else if (text.toLowerCase().includes('comparison')) {
        comparison.categories.push({
          category: 'Overall Assessment',
          yourReport: text.substring(0, 200) + '...',
          vetCtReport: 'See VET.CT Radiologists Report for complete expert analysis'
        });
      }
    }
    
    return { feedback, comparison, recommendations };
  }
}

serve(async (req) => {
  console.log('🚀 Generate feedback function called');
  
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Initialize Supabase client
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_ANON_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    // Get OpenAI API key
    const openAIApiKey = Deno.env.get('OPENAI_API_KEY');
    if (!openAIApiKey) {
      console.error('❌ OpenAI API key not found');
      throw new Error('OpenAI API key not configured');
    }

    // Parse request body
    const body = await req.json();
    console.log('📥 Request body:', JSON.stringify(body, null, 2));
    
    const { caseData } = body;
    if (!caseData) {
      throw new Error('Case data is required');
    }

    const { caseType, studyDescription, findings, conclusions, discussion } = caseData;
    
    // Fetch all case template data from database including ground truth
    const { data: caseTemplate } = await supabase
      .from('case_templates')
      .select('learning_objectives, next_steps, ground_truth, rubric, additional_documents')
      .eq('case_type', caseType)
      .single();

    console.log('📚 Case template data:', caseTemplate);
    
    // Use database-stored ground truth, fallback to a generic message if not found
    const groundTruth = caseTemplate?.ground_truth || 
      `VET.CT Radiologists Report for ${caseType} case - Ground truth data not available in database.`;
    
    // Create structured prompt for OpenAI to return JSON following the VET.CT feedback template
    const learningObjectivesText = caseTemplate?.learning_objectives ? 
      `\n\nLearning Objectives for this case:\n${caseTemplate.learning_objectives.map(obj => `- ${obj}`).join('\n')}` : '';
    
    const nextStepsText = caseTemplate?.next_steps ? 
      `\n\nExpected Next Steps:\n${caseTemplate.next_steps.map(step => `- ${step}`).join('\n')}` : '';

    // Build rubric information if available
    const rubricText = caseTemplate?.rubric ? 
      `\n\nScoring Rubric for this case:\n${JSON.stringify(caseTemplate.rubric, null, 2)}` : '';

    // Build additional documents information if available
    const additionalDocsText = caseTemplate?.additional_documents && 
      Object.keys(caseTemplate.additional_documents).length > 0 ? 
      `\n\nAdditional Reference Materials:\n${JSON.stringify(caseTemplate.additional_documents, null, 2)}` : '';

    const systemPrompt = `You are an expert veterinary radiologist providing educational feedback on student case submissions. 

There is a rubric for scoring students, identifying the key criteria they are assessed against${caseTemplate?.rubric ? ' (detailed below)' : ''}. There are a set of learning objectives for the student, outlined in: ${learningObjectivesText} which are the most important outcome of this exercise. We also expect them to understand the next step in clinical management of the patient should be: ${nextStepsText}.${rubricText}${additionalDocsText}
Write the feedback in a constructive manner, being very personable (in second person). Structure the feedback into sections, following the rubric style, without scores. Return the section level feedback in the following categories: 'Needs attention' (factually incorrect and multiple errors in interpretation), 'Room for improvement' (partially correct but needs more detail and thought), 'Mixed' (some correct and some obviously wrong), and 'Excellent' (good alignment with the radiologist's report). Provide a brief overall summary assessment at the start of the report on how good the interpretation is.

An expert VET.CT radiologist has also reviewed the images and their report is to be used as the ground truth. Whenever direct comparisons are made to the ground truth, please refer to them as the VET.CT radiologist, rather than expert etc. The overall style of the report should be encouraging them to continue to improve.

Focus your feedback on how well the student addressed the learning objectives above. Evaluate whether their interpretation and conclusions align with the educational goals for this case.

Analyze the student's submission against the VET.CT Radiologists Report and provide feedback following the VET.CT template structure in JSON format.

IMPORTANT: Do not use exclamation marks in titles. Keep titles concise and professional.

{
  "feedback": [
    {"title": "Technique", "type": "mixed", "content": "Assessment of study quality, positioning, technique, collimation, and appropriateness of views obtained..."},
    {"title": "Terminology", "type": "improvement", "content": "Evaluation of anatomical terminology usage - precision, appropriateness, and radiographic accuracy..."},
    {"title": "Description", "type": "mixed", "content": "Analysis of radiographic findings description - accuracy, completeness, and comparison to expert interpretation..."},
    {"title": "Use of Roentgen Signs", "type": "improvement", "content": "Assessment of systematic application of roentgen signs: size, shape, margins, opacity, number, location, effect on adjacent structures..."},
    {"title": "Report Organisation", "type": "positive", "content": "Evaluation of report structure, clarity, and systematic approach..."},
    {"title": "Differential Diagnosis", "type": "mixed", "content": "Analysis of differential diagnoses provided - appropriateness, prioritization, and clinical reasoning..."},
    {"title": "Next Steps", "type": "mixed", "content": "Assessment of recommended follow-up, additional diagnostics, and clinical management suggestions..."},
    {"title": "Anatomic Terms", "type": "improvement", "content": "Additional feedback on anatomical language and radiographic terminology that could enhance descriptions..."}
  ],
  "comparison": {
    "categories": [
      {
        "category": "Bone Changes",
        "yourReport": "Student's description of bone findings...",
        "vetCtReport": "Expert description of bone pathology..."
      },
      {
        "category": "Soft Tissues", 
        "yourReport": "Student's soft tissue observations...",
        "vetCtReport": "Expert soft tissue analysis..."
      },
      {
        "category": "Joints",
        "yourReport": "Student's joint assessment...",
        "vetCtReport": "Expert joint evaluation..."
      },
      {
        "category": "Differentials",
        "yourReport": "Student's differential diagnoses...",
        "vetCtReport": "Expert differential prioritization..."
      },
      {
        "category": "Next Steps",
        "yourReport": "Student's recommendations...",
        "vetCtReport": "Expert follow-up plan..."
      }
    ]
  },
  "recommendations": [
    "Differentiate lysis vs proliferation carefully - focus on margin analysis for aggressive vs chronic processes",
    "Apply roentgen signs systematically for every lesion: size, shape, margins, opacity, number, location, and effect on adjacent structures", 
    "Prioritize differential diagnoses based on signalment, history, and radiographic pattern",
    "Include specific follow-up recommendations: joint fluid analysis, culture, follow-up imaging timing",
    "Integrate radiographic findings with clinical presentation for comprehensive case management"
  ]
}

Focus on veterinary radiology education principles: systematic interpretation, precise terminology, roentgen signs application, and clinical correlation. The recommendations section should refer specifically to the learning objectives and next steps if any have not been addressed. However, importantly, the student is unaware of the specific learning objectives or expected next steps so please don't refer to them or say the phrase "learning objectives" in the feedback.

VET.CT Radiologists Report Information:
${groundTruth}`;

    const userPrompt = `Please analyze this veterinary case submission and provide structured feedback:

Case Type: ${caseType}
Study Description: ${studyDescription || 'Not provided'}
Student's Findings: ${findings || 'Not provided'}
Student's Conclusions: ${conclusions || 'Not provided'}
Student's Discussion: ${discussion || 'Not provided'}

Compare the student's work to the VET.CT Radiologists Report and return your analysis in the requested JSON format.`;

    console.log('📤 Calling OpenAI API...');
    
    // Call OpenAI API with correct parameters for gpt-4.1
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${openAIApiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'gpt-4.1-2025-04-14',
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: userPrompt }
        ],
        max_completion_tokens: 2000
        // Note: temperature parameter removed for gpt-4.1 compatibility
      }),
    });

    if (!response.ok) {
      const errorData = await response.json();
      console.error('❌ OpenAI API error:', errorData);
      throw new Error(`OpenAI API error: ${response.status} - ${JSON.stringify(errorData)}`);
    }

    const data = await response.json();
    console.log('✅ OpenAI response received');
    
    const rawContent = data.choices[0].message.content;
    console.log('📄 Raw OpenAI content:', rawContent);
    
    // Parse the structured response
    const structuredFeedback = parseFeedbackResponse(rawContent);
    console.log('📊 Structured feedback:', JSON.stringify(structuredFeedback, null, 2));

    return new Response(JSON.stringify({
      feedback: structuredFeedback.feedback || [],
      comparison: structuredFeedback.comparison || { categories: [] },
      recommendations: structuredFeedback.recommendations || [],
      status: 'success',
      caseType,
      timestamp: new Date().toISOString()
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error('💥 Error in generate-feedback function:', error);
    
    // Provide fallback structured response on error
    const fallbackResponse = {
      feedback: [
        { title: 'System Status', type: 'improvement', content: 'Unable to generate AI feedback at this time. Please try again later.' }
      ],
      comparison: {
        categories: [
          {
            category: 'System Status',
            yourReport: 'Submission received',
            vetCtReport: 'AI analysis temporarily unavailable'
          }
        ]
      },
      recommendations: [
        'Please retry your submission',
        'Check your internet connection',
        'Contact support if the issue persists'
      ],
      status: 'error',
      error: error.message
    };
    
    return new Response(JSON.stringify(fallbackResponse), {
      status: 200, // Return 200 with error in body for better UX
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});