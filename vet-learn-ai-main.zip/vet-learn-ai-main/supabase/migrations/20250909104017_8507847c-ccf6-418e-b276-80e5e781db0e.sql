-- Create table for case submissions
CREATE TABLE public.case_submissions (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID, -- Will reference auth.users when authentication is implemented
  case_type TEXT NOT NULL CHECK (case_type IN ('thoracic', 'abdominal', 'musculoskeletal')),
  case_title TEXT NOT NULL,
  signalment TEXT NOT NULL,
  history TEXT NOT NULL,
  image_links TEXT[], -- Array of image URLs
  study_description TEXT,
  findings TEXT,
  conclusions TEXT,
  discussion TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create table for case feedback
CREATE TABLE public.case_feedback (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  case_submission_id UUID NOT NULL REFERENCES public.case_submissions(id) ON DELETE CASCADE,
  ai_feedback JSONB, -- Store structured AI feedback
  personal_review TEXT,
  learning_rating INTEGER CHECK (learning_rating >= 1 AND learning_rating <= 5),
  difficulty_rating INTEGER CHECK (difficulty_rating >= 1 AND difficulty_rating <= 5),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable Row Level Security (temporarily permissive until auth is implemented)
ALTER TABLE public.case_submissions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.case_feedback ENABLE ROW LEVEL SECURITY;

-- Temporary permissive policies (should be restricted when auth is implemented)
CREATE POLICY "Allow all access to case_submissions" 
ON public.case_submissions 
FOR ALL 
USING (true) 
WITH CHECK (true);

CREATE POLICY "Allow all access to case_feedback" 
ON public.case_feedback 
FOR ALL 
USING (true) 
WITH CHECK (true);

-- Create function to update timestamps
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SET search_path = public;

-- Create triggers for automatic timestamp updates
CREATE TRIGGER update_case_submissions_updated_at
  BEFORE UPDATE ON public.case_submissions
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_case_feedback_updated_at
  BEFORE UPDATE ON public.case_feedback
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

-- Add indexes for better performance
CREATE INDEX idx_case_submissions_case_type ON public.case_submissions(case_type);
CREATE INDEX idx_case_submissions_created_at ON public.case_submissions(created_at);
CREATE INDEX idx_case_feedback_submission_id ON public.case_feedback(case_submission_id);