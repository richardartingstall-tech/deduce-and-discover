-- Fix security vulnerability: Implement proper RLS policies for case submissions and feedback

-- First, make user_id NOT NULL in case_submissions (it should always be required)
ALTER TABLE public.case_submissions 
ALTER COLUMN user_id SET NOT NULL;

-- Drop existing overly permissive policies
DROP POLICY IF EXISTS "Allow all access to case_submissions" ON public.case_submissions;
DROP POLICY IF EXISTS "Allow all access to case_feedback" ON public.case_feedback;

-- Create secure RLS policies for case_submissions
-- Users can only view their own submissions
CREATE POLICY "Users can view their own case submissions" 
ON public.case_submissions 
FOR SELECT 
USING (auth.uid() = user_id);

-- Users can only insert their own submissions
CREATE POLICY "Users can create their own case submissions" 
ON public.case_submissions 
FOR INSERT 
WITH CHECK (auth.uid() = user_id);

-- Users can only update their own submissions
CREATE POLICY "Users can update their own case submissions" 
ON public.case_submissions 
FOR UPDATE 
USING (auth.uid() = user_id);

-- Users can only delete their own submissions
CREATE POLICY "Users can delete their own case submissions" 
ON public.case_submissions 
FOR DELETE 
USING (auth.uid() = user_id);

-- Create secure RLS policies for case_feedback
-- Users can only view feedback for their own case submissions
CREATE POLICY "Users can view feedback for their own submissions" 
ON public.case_feedback 
FOR SELECT 
USING (
  EXISTS (
    SELECT 1 FROM public.case_submissions 
    WHERE case_submissions.id = case_feedback.case_submission_id 
    AND case_submissions.user_id = auth.uid()
  )
);

-- Users can only create feedback for their own case submissions
CREATE POLICY "Users can create feedback for their own submissions" 
ON public.case_feedback 
FOR INSERT 
WITH CHECK (
  EXISTS (
    SELECT 1 FROM public.case_submissions 
    WHERE case_submissions.id = case_feedback.case_submission_id 
    AND case_submissions.user_id = auth.uid()
  )
);

-- Users can only update feedback for their own case submissions
CREATE POLICY "Users can update feedback for their own submissions" 
ON public.case_feedback 
FOR UPDATE 
USING (
  EXISTS (
    SELECT 1 FROM public.case_submissions 
    WHERE case_submissions.id = case_feedback.case_submission_id 
    AND case_submissions.user_id = auth.uid()
  )
);

-- Users can only delete feedback for their own case submissions
CREATE POLICY "Users can delete feedback for their own submissions" 
ON public.case_feedback 
FOR DELETE 
USING (
  EXISTS (
    SELECT 1 FROM public.case_submissions 
    WHERE case_submissions.id = case_feedback.case_submission_id 
    AND case_submissions.user_id = auth.uid()
  )
);