-- Clean up existing data and implement proper security

-- First, delete existing case feedback that references case submissions without user_id
DELETE FROM public.case_feedback 
WHERE case_submission_id IN (
  SELECT id FROM public.case_submissions WHERE user_id IS NULL
);

-- Delete existing case submissions without user_id (these are test submissions)
DELETE FROM public.case_submissions WHERE user_id IS NULL;

-- Now make user_id NOT NULL since all remaining records should have user_id
ALTER TABLE public.case_submissions 
ALTER COLUMN user_id SET NOT NULL;

-- Drop existing overly permissive policies
DROP POLICY IF EXISTS "Allow all access to case_submissions" ON public.case_submissions;
DROP POLICY IF EXISTS "Allow all access to case_feedback" ON public.case_feedback;

-- Create secure RLS policies for case_submissions
CREATE POLICY "Users can view their own case submissions" 
ON public.case_submissions 
FOR SELECT 
USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own case submissions" 
ON public.case_submissions 
FOR INSERT 
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own case submissions" 
ON public.case_submissions 
FOR UPDATE 
USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own case submissions" 
ON public.case_submissions 
FOR DELETE 
USING (auth.uid() = user_id);

-- Create secure RLS policies for case_feedback
CREATE POLICY "Users can view feedback for their own submissions" 
ON public.case_feedback 
FOR SELECT 
USING (
  EXISTS (
    SELECT 1 FROM public.case_submissions 
    WHERE case_submissions.id = case_feedback.case_submission_id 
    AND case_submissions.user_id = auth.uid()
  )
);

CREATE POLICY "Users can create feedback for their own submissions" 
ON public.case_feedback 
FOR INSERT 
WITH CHECK (
  EXISTS (
    SELECT 1 FROM public.case_submissions 
    WHERE case_submissions.id = case_feedback.case_submission_id 
    AND case_submissions.user_id = auth.uid()
  )
);

CREATE POLICY "Users can update feedback for their own submissions" 
ON public.case_feedback 
FOR UPDATE 
USING (
  EXISTS (
    SELECT 1 FROM public.case_submissions 
    WHERE case_submissions.id = case_feedback.case_submission_id 
    AND case_submissions.user_id = auth.uid()
  )
);

CREATE POLICY "Users can delete feedback for their own submissions" 
ON public.case_feedback 
FOR DELETE 
USING (
  EXISTS (
    SELECT 1 FROM public.case_submissions 
    WHERE case_submissions.id = case_feedback.case_submission_id 
    AND case_submissions.user_id = auth.uid()
  )
);