-- Clean up and fix security policies properly

-- First, delete existing case feedback and submissions without user_id
DELETE FROM public.case_feedback 
WHERE case_submission_id IN (
  SELECT id FROM public.case_submissions WHERE user_id IS NULL
);

DELETE FROM public.case_submissions WHERE user_id IS NULL;

-- Drop ALL existing policies to start fresh
DO $$
DECLARE
    pol record;
BEGIN
    -- Drop all policies on case_submissions
    FOR pol IN 
        SELECT policyname 
        FROM pg_policies 
        WHERE tablename = 'case_submissions' AND schemaname = 'public'
    LOOP
        EXECUTE 'DROP POLICY IF EXISTS ' || quote_ident(pol.policyname) || ' ON public.case_submissions';
    END LOOP;
    
    -- Drop all policies on case_feedback
    FOR pol IN 
        SELECT policyname 
        FROM pg_policies 
        WHERE tablename = 'case_feedback' AND schemaname = 'public'
    LOOP
        EXECUTE 'DROP POLICY IF EXISTS ' || quote_ident(pol.policyname) || ' ON public.case_feedback';
    END LOOP;
END
$$;

-- Make user_id NOT NULL
ALTER TABLE public.case_submissions 
ALTER COLUMN user_id SET NOT NULL;

-- Create secure RLS policies for case_submissions
CREATE POLICY "Users can view their own case submissions" 
ON public.case_submissions 
FOR SELECT 
USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own case submissions" 
ON public.case_submissions 
FOR INSERT 
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own case submissions" 
ON public.case_submissions 
FOR UPDATE 
USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own case submissions" 
ON public.case_submissions 
FOR DELETE 
USING (auth.uid() = user_id);

-- Create secure RLS policies for case_feedback
CREATE POLICY "Users can view feedback for their own submissions" 
ON public.case_feedback 
FOR SELECT 
USING (
  EXISTS (
    SELECT 1 FROM public.case_submissions 
    WHERE case_submissions.id = case_feedback.case_submission_id 
    AND case_submissions.user_id = auth.uid()
  )
);

CREATE POLICY "Users can create feedback for their own submissions" 
ON public.case_feedback 
FOR INSERT 
WITH CHECK (
  EXISTS (
    SELECT 1 FROM public.case_submissions 
    WHERE case_submissions.id = case_feedback.case_submission_id 
    AND case_submissions.user_id = auth.uid()
  )
);

CREATE POLICY "Users can update feedback for their own submissions" 
ON public.case_feedback 
FOR UPDATE 
USING (
  EXISTS (
    SELECT 1 FROM public.case_submissions 
    WHERE case_submissions.id = case_feedback.case_submission_id 
    AND case_submissions.user_id = auth.uid()
  )
);

CREATE POLICY "Users can delete feedback for their own submissions" 
ON public.case_feedback 
FOR DELETE 
USING (
  EXISTS (
    SELECT 1 FROM public.case_submissions 
    WHERE case_submissions.id = case_feedback.case_submission_id 
    AND case_submissions.user_id = auth.uid()
  )
);