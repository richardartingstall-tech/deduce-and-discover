-- Disable RLS on case_submissions and case_feedback tables to allow anonymous access
ALTER TABLE public.case_submissions DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.case_feedback DISABLE ROW LEVEL SECURITY;

-- Drop existing RLS policies if they exist
DROP POLICY IF EXISTS "Users can view their own case submissions" ON public.case_submissions;
DROP POLICY IF EXISTS "Users can create their own case submissions" ON public.case_submissions;
DROP POLICY IF EXISTS "Users can update their own case submissions" ON public.case_submissions;
DROP POLICY IF EXISTS "Users can delete their own case submissions" ON public.case_submissions;

DROP POLICY IF EXISTS "Users can view their own case feedback" ON public.case_feedback;
DROP POLICY IF EXISTS "Users can create their own case feedback" ON public.case_feedback;
DROP POLICY IF EXISTS "Users can update their own case feedback" ON public.case_feedback;
DROP POLICY IF EXISTS "Users can delete their own case feedback" ON public.case_feedback;

-- Make user_id nullable for anonymous submissions
ALTER TABLE public.case_submissions ALTER COLUMN user_id DROP NOT NULL;