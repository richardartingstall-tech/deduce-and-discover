-- Create a table for case templates with learning objectives and next steps
CREATE TABLE public.case_templates (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  case_type TEXT NOT NULL UNIQUE,
  learning_objectives TEXT[],
  next_steps TEXT[],
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE public.case_templates ENABLE ROW LEVEL SECURITY;

-- Create policy for public read access (no authentication required)
CREATE POLICY "Case templates are publicly readable" 
ON public.case_templates 
FOR SELECT 
USING (true);

-- Create trigger for automatic timestamp updates
CREATE TRIGGER update_case_templates_updated_at
BEFORE UPDATE ON public.case_templates
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Insert the abdominal case learning objectives and next steps
INSERT INTO public.case_templates (case_type, learning_objectives, next_steps) VALUES (
  'abdominal',
  ARRAY[
    'Recognise intact status',
    'Describe the Mass effect and potential tissues of origin',
    'Special focus on Small intestinal displacement and separation of UB and colon',
    'Discuss Differential considerations for uteromegaly including premineralisation pregnancy'
  ],
  ARRAY[
    'Sonogram without Doppler (foetal heartbeats) and surgery'
  ]
);