-- Enable RLS on case_submissions table (seems to be missing)
ALTER TABLE public.case_submissions ENABLE ROW LEVEL SECURITY;

-- Add policies for case_submissions to allow anonymous submissions
CREATE POLICY "Anyone can view case submissions" 
ON public.case_submissions 
FOR SELECT 
USING (true);

CREATE POLICY "Anyone can create case submissions" 
ON public.case_submissions 
FOR INSERT 
WITH CHECK (true);

CREATE POLICY "Users can update their own submissions" 
ON public.case_submissions 
FOR UPDATE 
USING (user_id = auth.uid() OR user_id IS NULL);

CREATE POLICY "Users can delete their own submissions" 
ON public.case_submissions 
FOR DELETE 
USING (user_id = auth.uid() OR user_id IS NULL);