-- First, drop the overly permissive policies for case_submissions
DROP POLICY IF EXISTS "Anyone can view case submissions" ON public.case_submissions;
DROP POLICY IF EXISTS "Anyone can create case submissions" ON public.case_submissions;
DROP POLICY IF EXISTS "Users can update their own submissions" ON public.case_submissions;
DROP POLICY IF EXISTS "Users can delete their own submissions" ON public.case_submissions;

-- Create more restrictive policies for case_submissions
-- Allow anonymous creation but restrict viewing to own submissions
CREATE POLICY "Users can create anonymous submissions" 
ON public.case_submissions 
FOR INSERT 
WITH CHECK (true);

-- Only allow users to view their own submissions (or anonymous ones if not logged in)
CREATE POLICY "Users can view their own submissions" 
ON public.case_submissions 
FOR SELECT 
USING (user_id = auth.uid() OR (user_id IS NULL AND auth.uid() IS NULL));

-- Allow updating own submissions
CREATE POLICY "Users can update their own submissions" 
ON public.case_submissions 
FOR UPDATE 
USING (user_id = auth.uid() OR (user_id IS NULL AND auth.uid() IS NULL));

-- Allow deleting own submissions  
CREATE POLICY "Users can delete their own submissions" 
ON public.case_submissions 
FOR DELETE 
USING (user_id = auth.uid() OR (user_id IS NULL AND auth.uid() IS NULL));