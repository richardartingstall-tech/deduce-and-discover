-- Enable RLS on case_feedback table
ALTER TABLE public.case_feedback ENABLE ROW LEVEL SECURITY;