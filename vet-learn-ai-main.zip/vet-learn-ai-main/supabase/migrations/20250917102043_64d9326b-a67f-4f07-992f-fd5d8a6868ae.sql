-- Insert thoracic case template
INSERT INTO case_templates (case_type, learning_objectives, next_steps)
VALUES (
  'thoracic',
  ARRAY[
    'Discuss features of extrapleural sign',
    'Characterise rib lysis', 
    'Discuss significance of pleural effusion- direct metastasis'
  ],
  ARRAY[
    'Tissue sampling. Can consider CT for full staging'
  ]
)
ON CONFLICT (case_type) 
DO UPDATE SET 
  learning_objectives = EXCLUDED.learning_objectives,
  next_steps = EXCLUDED.next_steps,
  updated_at = now();

-- Insert musculoskeletal case template  
INSERT INTO case_templates (case_type, learning_objectives, next_steps)
VALUES (
  'musculoskeletal',
  ARRAY[
    'Describe common features across multiple images',
    'Recognise arthrocentric disease with soft tissue changes'
  ],
  ARRAY[
    'Joint fluid collection for analysis and culture. Serial radiographs to assess progression'
  ]
)
ON CONFLICT (case_type)
DO UPDATE SET 
  learning_objectives = EXCLUDED.learning_objectives,
  next_steps = EXCLUDED.next_steps,
  updated_at = now();