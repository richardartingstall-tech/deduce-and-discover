-- Expand case_templates table to support additional reference documents
ALTER TABLE case_templates 
ADD COLUMN ground_truth TEXT,
ADD COLUMN rubric JSONB,
ADD COLUMN additional_documents JSONB DEFAULT '{}';

-- Insert ground truth data for existing case types
UPDATE case_templates 
SET ground_truth = 'VET.CT Radiologists Report

STUDY DESCRIPTION: Thoracic radiographs

FINDINGS: 
There is a large soft tissue opacity in the cranial right thorax extending from the level of the 2nd rib to the level of the 6th rib. This opacity displaces the cardiac silhouette caudally and to the left. The opacity appears to be extrapleural in location based on the presence of an extrapleural sign - a smooth, well-defined interface between the opacity and the adjacent lung parenchyma that forms an obtuse angle with the chest wall.

There is evidence of osteolysis affecting the right 3rd, 4th, and 5th ribs in the region of the mass. The ribs show irregular, moth-eaten bone destruction consistent with aggressive bone involvement.

A moderate volume pleural effusion is present on the right side, evidenced by increased opacity in the ventral and caudal thoracic cavity with blunting of the costophrenic angle.

CONCLUSIONS:
The imaging findings are consistent with a large extrapleural mass with associated rib lysis and pleural effusion. The extrapleural location, aggressive bone destruction, and pleural effusion are highly suggestive of a malignant process, most likely a primary or metastatic neoplasm. The pleural effusion may represent direct metastatic spread or reactive fluid accumulation.

Differential diagnoses include:
1. Primary thoracic wall neoplasm (e.g., chondrosarcoma, osteosarcoma)
2. Metastatic disease to the thoracic wall
3. Primary pleural neoplasm with chest wall invasion

RECOMMENDATIONS:
Tissue sampling via fine needle aspiration or core biopsy is recommended for definitive diagnosis. Cross-sectional imaging (CT) should be considered for complete staging and surgical planning if indicated.'
WHERE case_type = 'thoracic';

UPDATE case_templates 
SET ground_truth = 'VET.CT Radiologists Report

STUDY DESCRIPTION: Musculoskeletal radiographs - multiple joints

FINDINGS:
Multiple joint abnormalities are present affecting several appendicular joints bilaterally.

In the stifle joints, there is joint space narrowing, subchondral bone sclerosis, and small osteophyte formation at the femoral condyles and tibial plateaus bilaterally. Joint effusion is evidenced by capsular distension.

The tarsal joints show similar changes with joint space narrowing, particularly affecting the tarsometatarsal and intertarsal articulations. Subchondral sclerosis and small periarticular osteophytes are present.

The carpal joints demonstrate joint space narrowing, subchondral sclerosis, and mild soft tissue swelling consistent with joint capsule thickening and possible effusion.

Soft tissue changes include:
- Periarticular soft tissue swelling around affected joints
- Joint capsule distension consistent with effusion
- No evidence of significant muscle atrophy

CONCLUSIONS:
The radiographic findings demonstrate a polyarthropathy affecting multiple joints with features consistent with inflammatory joint disease. The bilateral, symmetrical distribution and presence of joint effusions suggest an immune-mediated arthropathy rather than degenerative joint disease.

The combination of joint space narrowing, subchondral changes, and soft tissue swelling in multiple joints is most consistent with rheumatoid arthritis or another immune-mediated polyarthropathy.

RECOMMENDATIONS:
Joint fluid collection from one or more affected joints for cytological analysis and bacterial culture is strongly recommended. Serial radiographic monitoring should be performed to assess disease progression and response to treatment.'
WHERE case_type = 'musculoskeletal';

UPDATE case_templates 
SET ground_truth = 'VET.CT Radiologists Report

STUDY DESCRIPTION: Abdominal radiographs

FINDINGS:
The abdominal study demonstrates organomegaly affecting multiple organs within the peritoneal cavity.

The liver appears enlarged with rounded margins extending beyond the costal arch. Hepatomegaly is evidenced by caudal displacement of the gastric axis and increased opacity in the cranial abdomen.

The spleen shows marked enlargement with increased opacity in the left cranial and mid-abdomen, displacing bowel loops centrally and to the right.

Both kidneys appear enlarged based on their relationship to adjacent structures, though specific measurements cannot be obtained from plain radiographs.

There is decreased abdominal detail consistent with the presence of peritoneal effusion. The normal peritoneal fat plane is obscured, and there is a ground-glass appearance to the abdomen.

Small bowel loops show mild dilation with some gas distension, possibly secondary to the space-occupying effects of the enlarged organs and fluid accumulation.

CONCLUSIONS:
The radiographic findings demonstrate hepatosplenomegaly with bilateral renomegaly and peritoneal effusion. This constellation of findings suggests a systemic disease process affecting multiple organ systems.

Differential diagnoses include:
1. Lymphoma (most likely given the multi-organ involvement)
2. Systemic fungal infection
3. Mast cell disease with systemic involvement
4. Other round cell neoplasms

The combination of organomegaly and effusion warrants immediate further investigation.

RECOMMENDATIONS:
Abdominal ultrasonography for detailed assessment of organ architecture and guided sampling. Abdominocentesis for fluid analysis. Complete staging including thoracic radiographs and hematological evaluation.'
WHERE case_type = 'abdominal';