-- Update RLS policies for case_feedback to allow anonymous submissions
-- Drop existing policies
DROP POLICY IF EXISTS "Users can create feedback for their own submissions" ON public.case_feedback;
DROP POLICY IF EXISTS "Users can view feedback for their own submissions" ON public.case_feedback;
DROP POLICY IF EXISTS "Users can update feedback for their own submissions" ON public.case_feedback;
DROP POLICY IF EXISTS "Users can delete feedback for their own submissions" ON public.case_feedback;

-- Create new policies that handle both authenticated and anonymous submissions
CREATE POLICY "Users can create feedback for their own submissions or anonymous submissions" 
ON public.case_feedback 
FOR INSERT 
WITH CHECK (
  EXISTS (
    SELECT 1 
    FROM case_submissions 
    WHERE case_submissions.id = case_feedback.case_submission_id 
    AND (
      (case_submissions.user_id = auth.uid()) 
      OR (case_submissions.user_id IS NULL AND auth.uid() IS NULL)
    )
  )
);

CREATE POLICY "Users can view feedback for their own submissions or anonymous submissions" 
ON public.case_feedback 
FOR SELECT 
USING (
  EXISTS (
    SELECT 1 
    FROM case_submissions 
    WHERE case_submissions.id = case_feedback.case_submission_id 
    AND (
      (case_submissions.user_id = auth.uid()) 
      OR (case_submissions.user_id IS NULL AND auth.uid() IS NULL)
    )
  )
);

CREATE POLICY "Users can update feedback for their own submissions or anonymous submissions" 
ON public.case_feedback 
FOR UPDATE 
USING (
  EXISTS (
    SELECT 1 
    FROM case_submissions 
    WHERE case_submissions.id = case_feedback.case_submission_id 
    AND (
      (case_submissions.user_id = auth.uid()) 
      OR (case_submissions.user_id IS NULL AND auth.uid() IS NULL)
    )
  )
);

CREATE POLICY "Users can delete feedback for their own submissions or anonymous submissions" 
ON public.case_feedback 
FOR DELETE 
USING (
  EXISTS (
    SELECT 1 
    FROM case_submissions 
    WHERE case_submissions.id = case_feedback.case_submission_id 
    AND (
      (case_submissions.user_id = auth.uid()) 
      OR (case_submissions.user_id IS NULL AND auth.uid() IS NULL)
    )
  )
);